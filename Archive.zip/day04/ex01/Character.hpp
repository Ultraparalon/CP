/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:36:16 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:36:17 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHARACTER_H
# define CHARACTER_H

# include <iostream>
# include "AWeapon.hpp"
# include "Enemy.hpp"

class Character
{
	std::string	_name;
	int			_ap;
	int			_max_ap;
	AWeapon	*	_weapon;

public:
	Character();
	Character(std::string const &);
	Character(Character const &);
	~Character();

	void	setName(std::string const &);
	void	setAP(int const &);
	void	setMaxAP(int const &);
	
	std::string	getName() const;
	int			getAP() const;
	int			getMaxAP() const;
	AWeapon *	getWeapon() const;

	void	recoverAP();
	void	equip(AWeapon *);
	void	attack(Enemy *);

	Character &	operator=(Character const &);	
};

std::ostream &	operator<<(std::ostream &, Character const &);

#endif
