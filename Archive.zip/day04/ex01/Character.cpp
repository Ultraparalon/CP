/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:36:10 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:36:11 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Character.hpp"

Character::Character() : _name("Johnny"), _ap(40), _max_ap(40), _weapon(NULL) {}

Character::Character(std::string const & name) : _name(name), _ap(40), _max_ap(40), _weapon(NULL) {}

Character::Character(Character const & obj)	{	*this = obj;	}

Character::~Character() {}

void	Character::setName(std::string const & str)	{	_name = str;	}
void	Character::setAP(int const & val)			{	_ap = val;		}
void	Character::setMaxAP(int const & val)		{	_max_ap = val;	}

std::string	Character::getName() const	{	return _name;	}
int			Character::getAP() const	{	return _ap;		}
int			Character::getMaxAP() const	{	return _max_ap;	}
AWeapon *	Character::getWeapon() const{	return _weapon;	}

void	Character::recoverAP()
{
	_ap = (_ap + 10 > _max_ap) ? _max_ap : _ap + 10;
}

void	Character::equip(AWeapon * weapon)
{
	_weapon = weapon;
}

void	Character::attack(Enemy * enemy)
{
	if (_weapon && enemy)
	{
		if (_weapon->getAPCost() < _ap)
		{
			std::cout << _name << " attacks " << enemy->getType() << " with a " << _weapon->getName() << '\n';
			_ap -= _weapon->getAPCost();
			_weapon->attack();
			enemy->setHP(enemy->getHP() - _weapon->getDamage());
			if (enemy->getHP() <= 0)
				delete enemy;
		}
		else
			std::cout << "Not enough action points.\n";
	}
}

Character &	Character::operator=(Character const & obj)
{
	_name = obj.getName();
	_ap = obj.getAP();
	_max_ap = obj.getMaxAP();
	_weapon = obj.getWeapon();
	return *this;
}

std::ostream &	operator<<(std::ostream & stream, Character const & obj)
{
	if (obj.getWeapon())
	{
		stream << obj.getName() << " has " <<  obj.getAP() << '/' << obj.getMaxAP() << " AP and wields a " << obj.getWeapon()->getName() << '\n';
	}
	else
		stream << obj.getName() << " has " <<  obj.getAP() << '/' << obj.getMaxAP() << " AP and is unarmed.\n";
	return stream;
}
