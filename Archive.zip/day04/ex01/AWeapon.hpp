/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AWeapon.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:33:38 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:33:40 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AWEAPON_H
# define AWEAPON_H

# include <string>

class AWeapon
{
	std::string	_name;
	int			_apcost;
	int			_damage;

public:
	AWeapon();
	AWeapon(std::string const &, int, int);
	AWeapon(AWeapon const &);
	virtual ~AWeapon();

	void	setName(std::string const &);
	void	setAPCost(int const &);
	void	setDamage(int const &);

	std::string getName() const;
	int	getAPCost() const;
	int	getDamage() const;

	virtual	void	attack() const = 0;

	AWeapon & operator=(AWeapon const &);
	
};

#endif
