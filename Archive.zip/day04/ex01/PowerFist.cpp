/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PowerFist.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:34:22 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:34:26 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PowerFist.hpp"

PowerFist::PowerFist() : AWeapon("Power Fist", 8, 50) {}

PowerFist::PowerFist(PowerFist const & obj)	{	*this = obj;	}

PowerFist::~PowerFist() {}

void	PowerFist::attack() const
{
	std::cout << "* pschhh... SBAM! *\n";
}

PowerFist &	PowerFist::operator=(PowerFist const & obj)
{
	AWeapon::operator=(obj);
	return *this;
}
