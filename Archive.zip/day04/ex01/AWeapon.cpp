/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AWeapon.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:33:48 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:33:49 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "AWeapon.hpp"

AWeapon::AWeapon() : _name("default"), _apcost(10), _damage(1) {}

AWeapon::AWeapon(std::string const & name, int apcost, int damage) : _name(name), _apcost(apcost), _damage(damage) {}

AWeapon::AWeapon(AWeapon const & obj)	{	*this = obj;	}

AWeapon::~AWeapon() {}

void	AWeapon::setName(std::string const & str)	{	_name = str;	}
void	AWeapon::setAPCost(int const & val)			{	_apcost = val;	}
void	AWeapon::setDamage(int const & val)			{	_damage = val;	}

std::string	AWeapon::getName() const	{	return _name;	}
int			AWeapon::getAPCost() const	{	return _apcost;	}
int			AWeapon::getDamage() const	{	return _damage;	}

AWeapon &	AWeapon::operator=(AWeapon const & obj)
{
	this->_name = obj.getName();
	this->_apcost = obj.getAPCost();
	this->_damage = obj.getDamage();
	return *this;
}
