/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperMutant.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:35:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:35:21 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "SuperMutant.hpp"

SuperMutant::SuperMutant() : Enemy(170, "Super Mutant")
{
	std::cout << "Gaaah. Me want smash heads !\n";
}

SuperMutant::SuperMutant(SuperMutant const & obj) {	*this = obj;	}

SuperMutant::~SuperMutant()
{
	std::cout << "Aaargh ...\n";
}

void	SuperMutant::takeDamage(int	val)
{
	val -= 3;
	Enemy::takeDamage(val);
}

SuperMutant &	SuperMutant::operator=(SuperMutant const & obj)
{
	Enemy::operator=(obj);
	return *this;
}
