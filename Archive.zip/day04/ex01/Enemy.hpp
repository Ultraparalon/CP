/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Enemy.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:34:52 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:34:53 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENEMY_H
# define ENEMY_H

# include <string>

class Enemy
{
	std::string	_type;
	int			_hp;

public:
	Enemy();
	Enemy(int, std::string const &);
	Enemy(Enemy const &);
	virtual ~Enemy();

	void	setType(std::string const &);
	void	setHP(int);

	std::string	getType() const;
	int			getHP() const;

	virtual void	takeDamage(int);

	Enemy &	operator=(Enemy const &);
	
};

#endif
