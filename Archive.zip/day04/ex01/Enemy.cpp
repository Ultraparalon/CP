/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Enemy.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 17:34:46 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 17:34:47 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Enemy.hpp"

Enemy::Enemy() : _type("default"), _hp(999) {}

Enemy::Enemy(int hp, std::string const & type) : _type(type), _hp(hp) {}

Enemy::Enemy(Enemy const & obj)	{	*this = obj;	}

Enemy::~Enemy() {}

void	Enemy::setType(std::string const & str)	{	_type = str;	}
void	Enemy::setHP(int val)					{	_hp = val;		}

std::string	Enemy::getType() const	{	return _type;	}
int			Enemy::getHP() const	{	return _hp;		}

void	Enemy::takeDamage(int val)
{
	if (val > 0)
	{
		_hp -= val;
	}
}

Enemy &	Enemy::operator=(Enemy const & obj)
{
	this->_type = obj.getType();
	this->_hp = obj.getHP();
	return *this;
}
