/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Squad.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:02:03 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:02:05 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SQUAD_H
# define SQUAD_H

# include <iostream>
# include "ISquad.hpp"

class Squad : public ISquad
{
	typedef struct			_squadlist
	{
		ISpaceMarine *		marine;
		struct _squadlist *	next;		
	}						t_squadlist;

	int						_count;
	t_squadlist *			_marines;

public:
	Squad();
	Squad(Squad const &);
	virtual ~Squad();

	int				getCount() const;

	ISpaceMarine *	getUnit(int) const;
	int				push(ISpaceMarine *);

	Squad &	operator=(Squad const &);
	
};

#endif
