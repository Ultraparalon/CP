/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TacticalMarine.cpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:02:23 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:02:26 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "TacticalMarine.hpp"

TacticalMarine::TacticalMarine()
{
	std::cout << "Tactical Marine ready for battle\n";
}

TacticalMarine::TacticalMarine(TacticalMarine const & obj) {	*this = obj;	}

TacticalMarine::~TacticalMarine()
{
	std::cout << "Aaargh ...\n";
}

ISpaceMarine *	TacticalMarine::clone() const
{
	return new TacticalMarine(*this);
}

void	TacticalMarine::battleCry() const
{
	std::cout << "BLOOD FOR THE BLOOD GOD! SKULLS FOR THE SKULL THRONE!\n";
}

void	TacticalMarine::rangedAttack() const
{
	std::cout << "* attacks with bolter *\n";
}

void	TacticalMarine::meleeAttack() const
{
	std::cout << "* attacks with chainsword *\n";
}

TacticalMarine &	TacticalMarine::operator=(TacticalMarine const &)
{
	return (*this);
}
