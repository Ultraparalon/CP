/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AssaultTerminator.cpp                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:02:59 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:03:00 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "AssaultTerminator.hpp"

AssaultTerminator::AssaultTerminator()
{
	std::cout << "* teleports from space *\n";
}

AssaultTerminator::AssaultTerminator(AssaultTerminator const & obj) {	*this = obj;	}

AssaultTerminator::~AssaultTerminator()
{
	std::cout << "I’ll be back ...\n";
}

ISpaceMarine *	AssaultTerminator::clone() const
{
	return new AssaultTerminator(*this);
}

void	AssaultTerminator::battleCry() const
{
	std::cout << "This code is heresy. PURIFY IT WITH FIRE!\n";
}

void	AssaultTerminator::rangedAttack() const
{
	std::cout << "* does nothing *\n";
}

void	AssaultTerminator::meleeAttack() const
{
	std::cout << "* attacks with chainfists *\n";
}

AssaultTerminator &	AssaultTerminator::operator=(AssaultTerminator const &)
{
	return (*this);
}
