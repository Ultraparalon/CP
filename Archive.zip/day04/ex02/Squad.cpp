/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Squad.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:01:55 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:01:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Squad.hpp"

Squad::Squad() : _count(0), _marines(NULL) {}

Squad::Squad(Squad const & obj)	{	*this = obj;	}

Squad::~Squad()
{
	t_squadlist *	tmp;

	while (this->_marines)
	{
		tmp = this->_marines;
		this->_marines = this->_marines->next;
		delete tmp->marine;
		delete tmp;
	}
}

int	Squad::getCount() const	{	return _count;	}

ISpaceMarine *	Squad::getUnit(int	val) const
{
	t_squadlist *	tmp = this->_marines;

	while (val-- && tmp)
		tmp = tmp->next;

	return (tmp->marine);

}

int	Squad::push(ISpaceMarine * obj)
{
	t_squadlist *	tmp = _marines;

	if (!obj || (tmp && tmp->marine == obj))
		return (_count);

	if (!tmp)
	{
		_marines = new t_squadlist;
		_marines->marine = obj;
		_marines->next = NULL;
		
		return (++_count);
	}

	while(tmp->next)
	{
		if (tmp->next->marine == obj)
			return (_count);
		tmp = tmp->next;
	}
	tmp->next = new t_squadlist;
	tmp->next->marine = obj;
	tmp->next->next = NULL;

	return (++_count);
}

Squad &	Squad::operator=(Squad const & obj)
{
	this->_count = obj.getCount();

	t_squadlist *	tmp;

	while (this->_marines)
	{
		tmp = this->_marines;
		this->_marines = this->_marines->next;
		delete tmp->marine;
		delete tmp;
	}

	tmp = this->_marines;
	t_squadlist	*	get = obj._marines;

	while (get)
	{
		tmp = new t_squadlist;
		tmp->marine = get->marine;
		tmp->next = NULL;
		tmp = tmp->next;
		get = get->next;
	}
	return (*this);
}
