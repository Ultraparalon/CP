/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AssaultTerminator.hpp                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:02:55 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:02:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ASSAULTTERMINATOR_H
# define ASSAULTTERMINATOR_H

# include <iostream>
# include "ISpaceMarine.hpp"

class AssaultTerminator : public ISpaceMarine
{

public:
	AssaultTerminator();
	AssaultTerminator(AssaultTerminator const &);
	virtual ~AssaultTerminator();

	ISpaceMarine *	clone() const;
	void			battleCry() const;
	void			rangedAttack() const;
	void			meleeAttack() const;

	AssaultTerminator &	operator=(AssaultTerminator const &);
	
};

#endif
