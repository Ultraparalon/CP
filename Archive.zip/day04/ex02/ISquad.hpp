/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ISquad.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:24:01 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:24:03 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ISQUAD_H
# define ISQUAD_H

#include "ISpaceMarine.hpp"

class ISquad
{
	
public:
	virtual ~ISquad() {}

	virtual ISpaceMarine *	getUnit(int) const = 0;
	virtual int				getCount() const = 0;
	virtual int				push(ISpaceMarine *) = 0;
	
};

#endif
