/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:03:45 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:03:49 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "TacticalMarine.hpp"
#include "AssaultTerminator.hpp"
#include "Squad.hpp"
#include <cstdlib>

void	test()
{
	ISpaceMarine* bob = new TacticalMarine;
	ISpaceMarine* jim = new AssaultTerminator;

	ISquad* vlc = new Squad;
	vlc->push(bob);
	vlc->push(jim);
	for (int i = 0; i < vlc->getCount(); ++i)
	{
		ISpaceMarine* cur = vlc->getUnit(i);
		cur->battleCry();
		cur->rangedAttack();
		cur->meleeAttack();
	}

	ISquad* suppasquad(vlc);
	for (int i = 0; i < suppasquad->getCount(); ++i)
	{
		ISpaceMarine* cur = suppasquad->getUnit(i);
		cur->battleCry();
		cur->rangedAttack();
		cur->meleeAttack();
	}

	suppasquad = vlc;
	for (int i = 0; i < suppasquad->getCount(); ++i)
	{
		ISpaceMarine* cur = suppasquad->getUnit(i);
		cur->battleCry();
		cur->rangedAttack();
		cur->meleeAttack();
	}

	ISquad *	tmp = new Squad;

	suppasquad = tmp;
	tmp = vlc;

	delete suppasquad;
	delete vlc;
}

int main()
{
	test();
	
	system("leaks warhammer");
	
	return 0;
}
