/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TacticalMarine.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 12:02:34 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 12:02:36 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef TACTICALMARINE_H
# define TACTICALMARINE_H

# include <iostream>
# include "ISpaceMarine.hpp"

class TacticalMarine : public ISpaceMarine
{

public:
	TacticalMarine();
	TacticalMarine(TacticalMarine const &);
	virtual ~TacticalMarine();

	ISpaceMarine *	clone() const;
	void			battleCry() const;
	void			rangedAttack() const;
	void			meleeAttack() const;

	TacticalMarine &	operator=(TacticalMarine const &);
	
};

#endif
