/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cure.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:49:12 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:49:13 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CURE_H
# define CURE_H

#include "AMateria.hpp"

class Cure : public AMateria
{

public:
	Cure();
	Cure(std::string const &);
	Cure(Cure const &);
	virtual ~Cure();

	AMateria*	clone() const;
	void		use(ICharacter &);

	Cure &	operator=(Cure const &);
	
};

#endif
