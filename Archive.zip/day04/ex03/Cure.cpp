/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cure.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:49:16 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:49:18 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Cure.hpp"

Cure::Cure() : AMateria("cure") {}

Cure::Cure(std::string const & type) : AMateria(type) {}

Cure::Cure(Cure const & obj)	{	*this = obj;	}

Cure::~Cure() {}

AMateria *	Cure::clone() const
{
	return new Cure("cure");
}

void	Cure::use(ICharacter & obj)
{
	AMateria::use(obj);
	std::cout << "* heals " << obj.getName() << "’s wounds *\n";
}

Cure &	Cure::operator=(Cure const & obj)
{
	AMateria::operator=(obj);
	return *this;
}
