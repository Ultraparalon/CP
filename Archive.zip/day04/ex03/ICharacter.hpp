/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ICharacter.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:50:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:50:20 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ICHARACTER_H
# define ICHARACTER_H

#include "AMateria.hpp"
#include "ICharacter.hpp"
#include <iostream>

class AMateria;

class ICharacter
{

public:
	virtual	~ICharacter() {}

	virtual std::string const &	getName() const = 0;
	virtual void				equip(AMateria *) = 0;
	virtual void				unequip(int) = 0;
	virtual void				use(int, ICharacter &) = 0;
		
};

#endif
