/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   IMateriaSource.hpp                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:50:37 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:50:40 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IMATERIASOURCE_H
# define IMATERIASOURCE_H

#include <iostream>
#include "AMateria.hpp"

class IMateriaSource
{

public:
	virtual ~IMateriaSource() {}

	virtual void		learnMateria(AMateria *) = 0;
	virtual AMateria *	createMateria(std::string const &) = 0;
	
};

#endif
