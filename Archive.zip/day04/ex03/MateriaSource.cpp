/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MateriaSource.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:50:03 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:50:04 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "MateriaSource.hpp"

MateriaSource::MateriaSource()
{
	for (int i = 0; i < 4; i++)
		_materia[i] = NULL;
}

MateriaSource::MateriaSource(MateriaSource const & obj)	{	*this = obj;	}

MateriaSource::~MateriaSource()
{
	for (int i = 0; i < 4; i++)
		delete _materia[i];
}

void	MateriaSource::learnMateria(AMateria * obj)
{
	if (obj)
	{
		for (int i = 0; i < 4; i++)
		{
			if (!_materia[i])
			{
				_materia[i] = obj;
				return ;
			}
		}
		std::cout << "Materia is full!\n";
	}
	else
		std::cout << "Nothing to add.\n";
}

AMateria *	MateriaSource::createMateria(std::string const & type)
{
	for (int i = 0; i < 4; i++)
		if (_materia[i] && _materia[i]->getType() == type)
			return _materia[i]->clone();
	return NULL;
}

MateriaSource &	MateriaSource::operator=(MateriaSource const & obj)
{
	for (int i = 0; i < 4; i++)
		delete _materia[i];

	for (int i = 0; i < 4; i++)
		_materia[i] = obj._materia[i]->clone();

	return *this;
}
