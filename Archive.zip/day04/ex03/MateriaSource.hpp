/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MateriaSource.hpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:49:55 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:49:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MATERIASOURCE_H
# define MATERIASOURCE_H

# include "IMateriaSource.hpp"

class MateriaSource : public IMateriaSource
{
	AMateria *	_materia[4];

public:
	MateriaSource();
	MateriaSource(MateriaSource const &);
	virtual ~MateriaSource();

	void		learnMateria(AMateria *);
	AMateria *	createMateria(std::string const &);

	MateriaSource &	operator=(MateriaSource const &);

};

#endif