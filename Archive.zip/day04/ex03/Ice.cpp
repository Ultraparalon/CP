/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ice.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:48:51 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:48:54 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Ice.hpp"

Ice::Ice() : AMateria("ice") {}

Ice::Ice(std::string const & type) : AMateria(type) {}

Ice::Ice(Ice const & obj)	{	*this = obj;	}

Ice::~Ice() {}

AMateria *	Ice::clone() const
{
	return new Ice("ice");
}

void	Ice::use(ICharacter & obj)
{
	AMateria::use(obj);
	std::cout << "* shoots an ice bolt at " << obj.getName() << " *\n";
}

Ice &	Ice::operator=(Ice const & obj)
{
	AMateria::operator=(obj);
	return *this;
}
