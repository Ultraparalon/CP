/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:49:30 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:49:31 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHARACTER_H
# define CHARACTER_H

#include "ICharacter.hpp"

class Character : public ICharacter
{
	std::string	_name;
	AMateria *	_materia[4];

public:
	Character();
	Character(std::string const &);
	Character(Character const &);
	virtual ~Character();

	std::string const &	getName() const;

	void	equip(AMateria *);
	void	unequip(int);
	void	use(int, ICharacter &);

	Character &	operator=(Character const &);
	
};

#endif
