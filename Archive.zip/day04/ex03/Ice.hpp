/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ice.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:48:44 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:48:45 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ICE_H
# define ICE_H

#include "AMateria.hpp"

class Ice : public AMateria
{

public:
	Ice();
	Ice(std::string const &);
	Ice(Ice const &);
	virtual ~Ice();

	AMateria*	clone() const;
	void		use(ICharacter &);

	Ice &	operator=(Ice const &);
	
};

#endif
