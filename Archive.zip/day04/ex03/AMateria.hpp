/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMateria.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:48:23 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:48:25 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AMATERIA_H
# define AMATERIA_H

#include <iostream>
#include "ICharacter.hpp"

class ICharacter;

class AMateria
{
	unsigned int	_xp;
	std::string		_type;

public:
	AMateria();
	AMateria(std::string const &);
	AMateria(AMateria const &);
	virtual ~AMateria();

	std::string const &	getType() const;
	unsigned int		getXP() const;

	virtual AMateria*	clone() const = 0;
	virtual void		use(ICharacter &);

	AMateria &	operator=(AMateria const &);
	
};

#endif
