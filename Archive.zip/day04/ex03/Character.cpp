/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:49:36 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:49:37 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Character.hpp"

Character::Character() : _name("Vasya")
{
	for (int i = 0; i < 4; i++)
		_materia[i] = NULL;
}

Character::Character(std::string const & name) : _name(name)
{
	for (int i = 0; i < 5; i++)
		_materia[i] = NULL;
}

Character::Character(Character const & obj) {	*this = obj;	}

Character::~Character()
{
	for (int i = 0; i < 4; i++)
		delete _materia[i];
}

std::string const & Character::getName() const {	return _name;	}

void	Character::equip(AMateria * obj)
{
	if (obj)
	{
		for (int i = 0; i < 4; i++)
		{
			if (!_materia[i])
			{
				_materia[i] = obj;
				return ;
			}
		}
		std::cout << "Inventory is full!\n";
	}
	else
		std::cout << "Nothing to equip.\n";
}

void	Character::unequip(int val)
{
	if (val < 4 && val >= 0 && _materia[val])
		_materia[val] = NULL;
	else
		std::cout << "Nothing to unequip.\n";
}

void	Character::use(int val, ICharacter & obj)
{
	if (val < 4 && val >=0 && _materia[val])
		_materia[val]->use(obj);
	else
		std::cout << "Nothing to use.\n";
}

Character &	Character::operator=(Character const & obj)
{
	for (int i = 0; i < 4; i++)
		delete _materia[i];

	_name = obj.getName();
	for (int i = 0; i < 4; i++)
	{
		_materia[i] = obj._materia[i]->clone();
	}

	return (*this);
}
