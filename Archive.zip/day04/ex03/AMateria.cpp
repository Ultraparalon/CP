/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMateria.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/06 16:48:34 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/06 16:48:35 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "AMateria.hpp"

AMateria::AMateria() : _xp(0), _type("default") {}

AMateria::AMateria(std::string const & type) : _xp(0), _type(type) {}

AMateria::AMateria(AMateria const & obj)	{	*this = obj;	}

AMateria::~AMateria() {}

std::string const &	AMateria::getType() const	{	return _type;	}
unsigned int		AMateria::getXP() const	{	return _xp;		}

void	AMateria::use(ICharacter &)
{
	_xp += 10;
}

AMateria &	AMateria::operator=(AMateria const & obj)
{
	_xp = obj.getXP();
	_type = obj.getType();
	return (*this);
}
