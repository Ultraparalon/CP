/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Victim.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 14:23:29 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 14:23:30 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VICTIM_H
# define VICTIM_H

#include <iostream>

class Victim
{
	std::string	_name;

public:
	Victim();
	Victim(std::string const &);
	Victim(Victim const &);
	~Victim();

	void	setName(std::string const &);

	std::string	getName() const;

	virtual void	getPolymorphed() const;

	Victim &	operator=(Victim const &);
};

std::ostream &	operator<<(std::ostream &, Victim const &);

#endif
