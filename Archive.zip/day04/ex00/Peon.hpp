/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Peon.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 14:23:51 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 14:23:52 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PEON_H
# define PEON_H

#include <iostream>
#include "Victim.hpp"

class Peon : public Victim
{

public:
	Peon();
	Peon(std::string const &);
	Peon(Peon const &);
	~Peon();
	
	void	getPolymorphed() const;

	Peon &	operator=(Peon const &);

};

std::ostream &	operator<<(std::ostream &, Peon const &);

#endif
