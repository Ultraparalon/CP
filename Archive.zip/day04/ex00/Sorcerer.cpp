/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Sorcerer.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 14:22:59 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 14:23:00 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Sorcerer.hpp"

Sorcerer::Sorcerer() : _name("Default"), _title("Default") {}

Sorcerer::Sorcerer(std::string const & name, std::string const & title) : _name(name), _title(title)
{
	std::cout << name << ", " << title << ", is born !\n";
}

Sorcerer::Sorcerer(Sorcerer const & obj)	{	*this = obj;	}

Sorcerer::~Sorcerer()
{
	std::cout << _name << ", " << _title << ", is dead. Consequences will never be the same !\n";
}

void	Sorcerer::setName(std::string const & str)	{	_name = str;	}
void	Sorcerer::setTitle(std::string const & str)	{	_title = str;	}

std::string	Sorcerer::getName() const	{	return _name;	}
std::string	Sorcerer::getTitle() const	{	return _title;	}

void	Sorcerer::polymorph(Victim const & obj) const
{
	obj.getPolymorphed();
}

Sorcerer &	Sorcerer::operator=(Sorcerer const & obj)
{
	this->_name = obj.getName();
	this->_title = obj.getTitle();
	return *this;
}

std::ostream & operator<<(std::ostream & stream, Sorcerer const & obj)
{
	stream << "I am " << obj.getName() << ", " << obj.getTitle() << ", and I like ponies !\n";
	return stream;
}
