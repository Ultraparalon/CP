/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Peon.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 14:23:46 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 14:23:47 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Peon.hpp"

Peon::Peon() {}

Peon::Peon(std::string const & name) : Victim(name)
{
	Victim::setName(name);
	std::cout << "Zog zog.\n";
}

Peon::Peon(Peon const & obj)
{
	*this = obj;
}

Peon::~Peon()
{
	std::cout << "Bleuark...\n";
}

void	Peon::getPolymorphed() const
{
	std::cout << this->getName() << " has beed turned into a pink pony !\n";
}

Peon &	Peon::operator=(Peon const & obj)
{
	this->setName(obj.getName());
	return *this;
}

std::ostream &	operator<<(std::ostream & stream, Peon const & obj)
{
	stream << "I'm " << obj.getName() << " and I like otters !\n";
	return stream;
}
