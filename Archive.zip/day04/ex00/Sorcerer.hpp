/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Sorcerer.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 14:23:06 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 14:23:07 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SORCERER_H
# define SORCERER_H

#include <iostream>
#include "Victim.hpp"

class Sorcerer
{
	std::string _name;
	std::string _title;

public:
	Sorcerer();
	Sorcerer(std::string const &, std::string const &);
	Sorcerer(Sorcerer const &);
	~Sorcerer();

	void	setName(std::string const &);
	void	setTitle(std::string const &);

	std::string	getName() const;
	std::string	getTitle() const;

	void	polymorph(Victim const &) const;

	Sorcerer &	operator=(Sorcerer const &);
};

std::ostream &	operator<<(std::ostream &, Sorcerer const &);

#endif
