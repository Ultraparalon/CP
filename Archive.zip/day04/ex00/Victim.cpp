/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Victim.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 14:23:33 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 14:23:34 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Victim.hpp"

Victim::Victim() : _name("Default") {}

Victim::Victim(std::string const & name) : _name(name)
{
	std::cout << "Some random victim called " << name << " just popped !\n";
}

Victim::Victim(Victim const & obj)	{	*this = obj;	}

Victim::~Victim()
{
	std::cout << "Victim " << _name << " just died for no apparent reason !\n";
}

void	Victim::setName(std::string const & str) {	_name = str;	}

std::string	Victim::getName() const	{	return _name;	}

void	Victim::getPolymorphed() const
{
	std::cout << _name << " has been turned into a cute little sheep !\n";
}

Victim &	Victim::operator=(Victim const & obj)
{
	this->_name = obj.getName();
	return *this;
}

std::ostream &	operator<<(std::ostream & stream, Victim const & obj)
{
	stream << "I'm " << obj.getName() << " and I like otters !\n";
	return stream;
}
