/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NinjaTrap.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 20:09:41 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 20:09:43 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "NinjaTrap.hpp"

NinjaTrap::NinjaTrap()
{
	ClapTrap::setHp(60);
	ClapTrap::setMaxHp(60);
	ClapTrap::setEnergy(120);
	ClapTrap::setMaxEnergy(120);
	ClapTrap::setLevel(1);
	ClapTrap::setMeleeDmg(60);
	ClapTrap::setRangedDmg(5);
	ClapTrap::setArmorRed(0);
	ClapTrap::setName("Ninja Trap");
	std::cout << "Ninja platform uploaded.\n";
}

NinjaTrap::NinjaTrap(std::string const & name)
{
	ClapTrap::setHp(60);
	ClapTrap::setMaxHp(60);
	ClapTrap::setEnergy(120);
	ClapTrap::setMaxEnergy(120);
	ClapTrap::setLevel(1);
	ClapTrap::setMeleeDmg(60);
	ClapTrap::setRangedDmg(5);
	ClapTrap::setArmorRed(0);
	ClapTrap::setName(name);
	std::cout << "Shiny " << name << " come to Pandora to eleminate vaulthuters.\n";
}

NinjaTrap::NinjaTrap(NinjaTrap const & clap)
{
	*this = clap;
	std::cout << "Oh! My eye just switched back on!\n"
	<< "I see a tough-looking minion, and an incredibly handsome robot!\n";
}

NinjaTrap::~NinjaTrap()
{
	std::cout << "Nothing can stop " << getName() << ", wait what is that?\n";
}

void	NinjaTrap::meleeAttack(std::string const & target)
{
	std::cout << "[sound of slicing]\n";
	ClapTrap::meleeAttack(target);
}


void	NinjaTrap::rangedAttack(std::string const & target)
{
	std::cout << "Shurikens are ready, prepare for your death!\n";
	ClapTrap::rangedAttack(target);
}

void	NinjaTrap::ninjaShoebox(ClapTrap & clap)
{
	if (getEnergy() - 25 >= 0)
	{
		setEnergy(getEnergy() - 25);
		std::cout << "Hey buddy, let me repair you...\n";
		clap.setHp(clap.getMaxHp());
		clap.setEnergy(clap.getMaxEnergy());
		std::cout << "Now, good as new.\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << clap.getName() << '\n';
	}
}

void	NinjaTrap::ninjaShoebox(FragTrap & clap)
{
	if (getEnergy() - 25 >= 0)
	{
		setEnergy(getEnergy() - 25);
		std::cout << "Not again this annoing thing.\n";
		std::cout << "Sound of slicing...\n";
		clap.setHp(0);
		std::cout << "No more stupid dances.\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << clap.getName() << '\n';
	}
}

void	NinjaTrap::ninjaShoebox(ScavTrap & clap)
{
	if (getEnergy() - 25 >= 0)
	{
		setEnergy(getEnergy() - 25);
		clap.challengeNewcomer(this->getName());
		std::cout << "What will you say about that Elon Musk?\n";
		std::cout << "[" << this->getName() << " become invisible]\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << clap.getName() << '\n';
	}
}

void	NinjaTrap::ninjaShoebox(NinjaTrap & clap)
{
	if (getEnergy() - 25 >= 0)
	{
		setEnergy(getEnergy() - 25);
		std::cout << "Now you'll share my fate!\n";
		clap = *this;
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << clap.getName() << '\n';
	}
}

NinjaTrap &	NinjaTrap::operator=(NinjaTrap const & clap)
{
	std::cout << getName() << " need new copy of himself\n";
	ClapTrap::operator=(clap);
	return *this;
}
