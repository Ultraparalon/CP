/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   NinjaTrap.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 20:09:51 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 20:09:53 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NINJATRAP_H
# define NINJATRAP_H

#include <iostream>
#include "ClapTrap.hpp"
#include "FragTrap.hpp"
#include "ScavTrap.hpp"

class NinjaTrap : public ClapTrap
{

public:
	NinjaTrap();
	NinjaTrap(NinjaTrap const & clap);
	NinjaTrap(std::string const & name);
	~NinjaTrap();

	void	meleeAttack(std::string const & target);
	void	rangedAttack(std::string const & target);
	void	ninjaShoebox(ClapTrap & clap);
	void	ninjaShoebox(FragTrap & clap);
	void	ninjaShoebox(ScavTrap & clap);
	void	ninjaShoebox(NinjaTrap & clap);

	NinjaTrap &	operator=(NinjaTrap const & clap);
	
};

#endif
