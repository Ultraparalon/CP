/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperTrap.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 10:18:58 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 10:19:01 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SUPERTRAP_H
# define SUPERTRAP_H

# include "ClapTrap.hpp"
# include "FragTrap.hpp"
# include "NinjaTrap.hpp"

class SuperTrap : public FragTrap, public NinjaTrap
{

public:
	SuperTrap();
	SuperTrap(SuperTrap const & clap);
	SuperTrap(std::string const & name);
	~SuperTrap();

	void	meleeAttack(std::string const & target);
	void	rangedAttack(std::string const & target);
	
	SuperTrap &	operator=(SuperTrap const & clap);
	
};

#endif
