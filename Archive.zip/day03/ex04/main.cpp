/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 12:25:11 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 12:25:13 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctime>
#include "FragTrap.hpp"
#include "ScavTrap.hpp"
#include "NinjaTrap.hpp"
#include "SuperTrap.hpp"

void	claptest()
{
	FragTrap clap;
	FragTrap frag("FR4G-TP");

	clap.displayStatus();
	frag.displayStatus();

	clap.meleeAttack("Skag");
	clap.rangedAttack("Psycho");
	clap.vaulthunter_dot_exe("Bandit");
	clap.vaulthunter_dot_exe("Warrior");
	clap.vaulthunter_dot_exe("Jack");
	clap.vaulthunter_dot_exe("Zarpedon");
	clap.vaulthunter_dot_exe("Constructor-bot");

	clap.takeDamage(3);
	clap.takeDamage(15);
	clap.displayStatus();

	FragTrap clapcopy(clap);
	clapcopy.displayStatus();

	frag = clap;
	frag.displayStatus();

	clap.beRepaired(5);
	clap.beRepaired(50);
	clap.displayStatus();
}

void	scavtest()
{
	ScavTrap clap;
	ScavTrap frag("BULL-TP");

	clap.displayStatus();
	frag.displayStatus();

	clap.meleeAttack("Skag");
	clap.rangedAttack("Psycho");
	clap.challengeNewcomer("Bandit");
	clap.challengeNewcomer("Warrior");
	clap.challengeNewcomer("Jack");
	clap.challengeNewcomer("Zarpedon");
	clap.challengeNewcomer("Constructor-bot");

	clap.takeDamage(3);
	clap.takeDamage(15);
	clap.displayStatus();

	ScavTrap clapcopy(clap);
	clapcopy.displayStatus();

	frag = clap;
	frag.displayStatus();

	clap.beRepaired(5);
	clap.beRepaired(50);
	clap.displayStatus();
}

void	ninjatest()
{
	NinjaTrap clap;
	NinjaTrap frag("Z3R0-TP");

	ClapTrap clapy("CL4P-TP");
	FragTrap fragy("FR4G-TP");
	ScavTrap scav("SC4V-TP");
	NinjaTrap ninja("N1NJ4-TP");

	clap.displayStatus();
	frag.displayStatus();

	clap.meleeAttack("Skag");
	clap.rangedAttack("Psycho");

	clap.ninjaShoebox(clapy);
	clapy.displayStatus();
	clap.ninjaShoebox(fragy);
	fragy.displayStatus();
	clap.ninjaShoebox(scav);
	scav.displayStatus();
	clap.ninjaShoebox(ninja);
	ninja.displayStatus();

	clap.takeDamage(3);
	clap.takeDamage(15);
	clap.displayStatus();

	NinjaTrap clapcopy(clap);
	clapcopy.displayStatus();

	frag = clap;
	frag.displayStatus();

	clap.beRepaired(5);
	clap.beRepaired(50);
	clap.displayStatus();
}

void	suppahot()
{
	SuperTrap	super;
	SuperTrap	mega("M3G4-B07");

	ClapTrap clapy("CL4P-TP");
	FragTrap fragy("FR4G-TP");
	ScavTrap scav("SC4V-TP");
	NinjaTrap ninja("N1NJ4-TP");

	super.displayStatus();
	mega.displayStatus();

	super.meleeAttack("Skag");
	super.rangedAttack("Psycho");

	super.ninjaShoebox(clapy);
	clapy.displayStatus();
	super.ninjaShoebox(fragy);
	fragy.displayStatus();
	super.ninjaShoebox(scav);
	scav.displayStatus();
	super.ninjaShoebox(ninja);
	ninja.displayStatus();

	super.takeDamage(3);
	super.takeDamage(15);
	super.displayStatus();

	NinjaTrap clapcopy(super);
	clapcopy.displayStatus();

	mega = super;
	mega.displayStatus();

	super.beRepaired(5);
	super.beRepaired(50);
	super.displayStatus();
}

int	main()
{
	srand(time(0));
	
	claptest();
	scavtest();
	ninjatest();
	suppahot();

	return (0);
}
