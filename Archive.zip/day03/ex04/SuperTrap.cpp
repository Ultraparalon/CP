/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   SuperTrap.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/05 10:18:37 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/05 10:18:42 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "SuperTrap.hpp"

SuperTrap::SuperTrap() : FragTrap(), NinjaTrap(true)
{
	ClapTrap::setName("Super Trap");
	std::cout << "Super platform uploaded.\n";
}

SuperTrap::SuperTrap(std::string const & name) : ClapTrap(name), FragTrap(name), NinjaTrap(name)
{
	ClapTrap::setName(name);
	std::cout << "God of all robots " << name << " come to save Universe!\n";
}

SuperTrap::SuperTrap(SuperTrap const & clap) : ClapTrap(clap), FragTrap(clap), NinjaTrap(clap)
{
	*this = clap;
	std::cout << "Super duper copy incoming!!!\n";
}

SuperTrap::~SuperTrap()
{
	std::cout << "Not so super...\n";
}

void	SuperTrap::meleeAttack(std::string const & target)
{
	NinjaTrap::meleeAttack(target);
}

void	SuperTrap::rangedAttack(std::string const & target)
{
	FragTrap::rangedAttack(target);
}

SuperTrap &	SuperTrap::operator=(SuperTrap const & clap)
{
	ClapTrap::operator=(clap);
	return *this;
}


