/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 12:24:51 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 12:24:52 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FragTrap.hpp"

FragTrap::FragTrap() : _hp(100), _max_hp(100), _energy(100), _max_energy(100), _level(1), _melee_dmg(30), _ranged_dmg(20), _armor_red(5), _name("Clap Trap")
{
	std::cout << "Greetings traveler!\n";
	std::cout << "I am C L 4 P T P steward-bot.\n";
	std::cout << "You may call me by my localy designated name Clap Trap.\n";
}

FragTrap::FragTrap(std::string const & name) : _hp(100), _max_hp(100), _energy(100), _max_energy(100), _level(1), _melee_dmg(30), _ranged_dmg(20), _armor_red(5), _name(name)
{
	std::cout << "Shiny " << name << " come to save Pandora, or Elpis, emm nevermind.\n";
}

FragTrap::FragTrap(FragTrap const & clap)
{
	*this = clap;
	std::cout << "Oh! My eye just switched back on!\n"
	<< "I see a tough-looking minion, and an incredibly handsome robot!\n";
}

FragTrap::~FragTrap()
{
	std::cout << "STAIRS?! NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO\n";
	std::cout << "Minion, you've gotta go on without me! Do your master " << _name << " proud!\n";
}

int			FragTrap::getHp() const			{	return _hp;			}
int			FragTrap::getMaxHp() const		{	return _max_hp;		}
int			FragTrap::getEnergy() const		{	return _energy;		}
int			FragTrap::getMaxEnergy() const	{	return _max_energy;	}
int			FragTrap::getLevel() const		{	return _level;		}
int			FragTrap::getMeleeDmg()	const	{	return _melee_dmg;	}
int			FragTrap::getRangedDmg() const	{	return _ranged_dmg;	}
int			FragTrap::getArmorRed()	const	{	return _armor_red;	}
std::string FragTrap::getName() const		{	return _name;		}

void	FragTrap::takeDamage(unsigned int amount)
{
	if ((int)amount > _armor_red)
	{
		_hp = (_hp - (int)amount >= 0) ? _hp - amount : 0;
		std::cout << "Ouch, thats hurts!\n";
		std::cout << "I feel pain of " << amount << "hp loss.\n";
		std::cout << "If your think that robots can't feel pain,\n";
		std::cout << "they actualy do, but in slowmotion.\n";
	}
	else
	{
		std::cout << "Mhahaha you cant't hurt me loser!\n";
	}
	
}

void	FragTrap::beRepaired(unsigned int amount)
{
	_hp += amount;
	_hp = (_max_hp > _hp) ? _hp : _max_hp;
	_energy += amount;
	_energy = (_max_energy > _energy) ? _energy : _max_energy;
	std::cout << _name << " restored his hp to " << _hp << " and energy to "
	<< _energy << " and ready to fight\n";
}

void	FragTrap::rangedAttack(std::string const & target)
{
	std::cout << _name << " attacks " << target << " at range, causing "
	<< _ranged_dmg << " points of damage!\n";
}

void	FragTrap::meleeAttack(std::string const & target)
{
	std::cout << _name << " attacks " << target << " with melee attack, causing "
	<< _melee_dmg << " points of damage!\n";
}

static std::string	actionSkill(int i)
{
	std::string	skill[] = 
	{
		"Clap-In-The-Box",
		"Gun Wizard",
		"Torgue Fiesta",
		"Pirate Sip Mode",
		"One Shot Wonder",
		"Laser Inferno",
		"Miniontrap",
		"Meat Unicycle",
		"Funzerker",
		"Mechromagician",
		"Shhhh... Trap!",
		"Blight Bot",
		"Rubber Ducky",
		"Senseless Sacrifice",
		"Medbot"
	};
	return (skill[i]);
}

void	FragTrap::vaulthunter_dot_exe(std::string const & target)
{
	if (_energy - 25 >= 0)
	{
		_energy -= 25;
		std::cout << _name << " performing special ability " << actionSkill(rand() % 15) << '\n';
		std::cout << target << " prepare for your doom!\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << target << '\n';
	}

}

void	FragTrap::displayStatus()
{
	std::cout << "\n     Name: " << _name << '\n';
	std::cout << "       Hp: " << _hp << '\n';
	std::cout << "    MaxHp: " << _max_hp << '\n';
	std::cout << "   Energy: " << _energy << '\n';
	std::cout << "MaxEnergy: " << _max_energy << '\n';
	std::cout << "    Level: " << _level << '\n';
	std::cout << "    Melee: " << _melee_dmg << '\n';
	std::cout << "   Ranged: " << _ranged_dmg << '\n';
	std::cout << "    Armor: " << _armor_red << "\n\n";
	std::cout << "oomc oomc oomc, oh check me out, I'm dancing, I'm dancing!\n\n";
}

FragTrap &	FragTrap::operator=(FragTrap const & clap)
{
	std::cout << "Phasecoping...\n";
	std::cout << "boop boop bup\n";
	std::cout << "Phasecopy ready\n";
	this->_hp = clap.getHp();
	this->_max_hp = clap.getMaxHp();
	this->_energy = clap.getEnergy();
	this->_max_energy = clap.getMaxEnergy();
	this->_level = clap.getLevel();
	this->_melee_dmg = clap.getMeleeDmg();
	this->_ranged_dmg = clap.getRangedDmg();
	this->_armor_red = clap.getArmorRed();
	this->_name = clap.getName();
	return *this;
}
