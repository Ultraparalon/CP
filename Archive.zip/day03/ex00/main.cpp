/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 12:25:11 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 12:25:13 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctime>
#include "FragTrap.hpp"


int	main()
{
	srand(time(0));

	FragTrap clap;
	FragTrap frag("FR4G-TP");

	clap.displayStatus();
	frag.displayStatus();

	clap.meleeAttack("Skag");
	clap.rangedAttack("Psycho");
	clap.vaulthunter_dot_exe("Bandit");
	clap.vaulthunter_dot_exe("Warrior");
	clap.vaulthunter_dot_exe("Jack");
	clap.vaulthunter_dot_exe("Zarpedon");
	clap.vaulthunter_dot_exe("Constructor-bot");

	clap.takeDamage(3);
	clap.takeDamage(15);
	clap.displayStatus();

	FragTrap clapcopy(clap);
	clapcopy.displayStatus();

	frag = clap;
	frag.displayStatus();

	clap.beRepaired(5);
	clap.beRepaired(50);
	clap.displayStatus();

	return (0);
}
