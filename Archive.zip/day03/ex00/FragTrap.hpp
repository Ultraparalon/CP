/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 12:25:01 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 12:25:02 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRAGTRAP_H
# define FRAGTRAP_H

#include <iostream>

class FragTrap
{
	int _hp;
	int	_max_hp;
	int _energy;
	int	_max_energy;
	int	_level;
	int	_melee_dmg;
	int	_ranged_dmg;
	int	_armor_red;
	std::string	_name;

public:
	FragTrap();
	FragTrap(FragTrap const & clap);
	FragTrap(std::string const & name);
	~FragTrap();

	int	getHp() const;
	int	getMaxHp() const;
	int	getEnergy() const;
	int	getMaxEnergy() const;
	int	getLevel() const;
	int	getMeleeDmg() const;
	int	getRangedDmg() const;
	int	getArmorRed() const;
	std::string	getName() const;

	void	takeDamage(unsigned int amount);
	void	beRepaired(unsigned int amount);

	void	rangedAttack(std::string const & target);
	void	meleeAttack(std::string const & target);
	void	vaulthunter_dot_exe(std::string const & target);
	void	displayStatus();

	FragTrap &	operator=(FragTrap const & clap);
	
};

#endif
