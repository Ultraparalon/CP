/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 17:15:37 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 17:15:38 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLAPTRAP_H
# define CLAPTRAP_H

# include <iostream>

class ClapTrap
{
	int _hp;
	int	_max_hp;
	int _energy;
	int	_max_energy;
	int	_level;
	int	_melee_dmg;
	int	_ranged_dmg;
	int	_armor_red;
	std::string	_name;

public:
	ClapTrap();
	ClapTrap(ClapTrap const & clap);
	ClapTrap(std::string const & name);
	~ClapTrap();

	int	getHp() const;
	int	getMaxHp() const;
	int	getEnergy() const;
	int	getMaxEnergy() const;
	int	getLevel() const;
	int	getMeleeDmg() const;
	int	getRangedDmg() const;
	int	getArmorRed() const;
	std::string	getName() const;

	void	setHp(int const & val);
	void	setMaxHp(int const & val);
	void	setEnergy(int const & val);
	void	setMaxEnergy(int const & val);
	void	setLevel(int const & val);
	void	setMeleeDmg(int const & val);
	void	setRangedDmg(int const & val);
	void	setArmorRed(int const & val);
	void	setName(std::string const & str);

	void	takeDamage(unsigned int amount);
	void	beRepaired(unsigned int amount);
	void	rangedAttack(std::string const & target);
	void	meleeAttack(std::string const & target);
	void	displayStatus();

	ClapTrap &	operator=(ClapTrap const & clap);
	
};

#endif
