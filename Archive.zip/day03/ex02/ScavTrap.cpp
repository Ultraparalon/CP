/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 16:32:17 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 16:32:19 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ScavTrap.hpp"

ScavTrap::ScavTrap()
{
	ClapTrap::setHp(100);
	ClapTrap::setMaxHp(100);
	ClapTrap::setEnergy(50);
	ClapTrap::setMaxEnergy(50);
	ClapTrap::setLevel(1);
	ClapTrap::setMeleeDmg(20);
	ClapTrap::setRangedDmg(15);
	ClapTrap::setArmorRed(3);
	ClapTrap::setName("Scav Trap");
	std::cout << "Scav platform uploaded.\n";
}

ScavTrap::ScavTrap(std::string const & name)
{
	ClapTrap::setHp(100);
	ClapTrap::setMaxHp(100);
	ClapTrap::setEnergy(50);
	ClapTrap::setMaxEnergy(50);
	ClapTrap::setLevel(1);
	ClapTrap::setMeleeDmg(20);
	ClapTrap::setRangedDmg(15);
	ClapTrap::setArmorRed(3);
	ClapTrap::setName(name);
	std::cout << "Shiny " << name << " is waiting for challange.\n";
}

ScavTrap::ScavTrap(ScavTrap const & clap)
{
	*this = clap;
	std::cout << "Oh! My eye just switched back on!\n"
	<< "I see a tough-looking minion, and an incredibly handsome robot!\n";
}

ScavTrap::~ScavTrap()
{
	std::cout << "Badass " << getName() << ", don't afraid of challenges.\n";
	std::cout << "So, what is your challenge?\n";
}

static std::string	challenge(int i)
{
	std::string	skill[] = 
	{
		"collect 139,377 brown rocks",
		"defeat Ug-Thak, Lord of Skags",
		"pilfer lost staff of Mount Schuler",
		"defeat Destroyer of Worlds",
		"dance, dance, baby",
		"find a life",
		"find claptrap's secret stash"
	};
	return (skill[i]);
}

void	ScavTrap::meleeAttack(std::string const & target)
{
	std::cout << "Maybe we just dance?\n";
	ClapTrap::meleeAttack(target);
}


void	ScavTrap::rangedAttack(std::string const & target)
{
	std::cout << "What about this challenge? Bullet in your brain!\n";
	ClapTrap::rangedAttack(target);
}

void	ScavTrap::challengeNewcomer(std::string const & target)
{
	if (getEnergy() - 25 >= 0)
	{
		setEnergy(getEnergy() - 25);
		std::cout << getName() << " have a new challenge: " << challenge(rand() % 7) << '\n';
		std::cout << target << " are you ready for this?\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << target << '\n';
	}

}

ScavTrap &	ScavTrap::operator=(ScavTrap const & clap)
{
	std::cout << getName() << " need new copy of himself\n";
	ClapTrap::operator=(clap);
	return *this;
}
