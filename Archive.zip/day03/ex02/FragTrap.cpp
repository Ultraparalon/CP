/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 12:24:51 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 12:24:52 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FragTrap.hpp"

FragTrap::FragTrap()
{
	ClapTrap::setHp(100);
	ClapTrap::setMaxHp(100);
	ClapTrap::setEnergy(100);
	ClapTrap::setMaxEnergy(100);
	ClapTrap::setLevel(1);
	ClapTrap::setMeleeDmg(30);
	ClapTrap::setRangedDmg(20);
	ClapTrap::setArmorRed(5);
	ClapTrap::setName("Frag Trap");
	std::cout << "Frag platform uploaded.\n";
}

FragTrap::FragTrap(std::string const & name)
{
	ClapTrap::setHp(100);
	ClapTrap::setMaxHp(100);
	ClapTrap::setEnergy(100);
	ClapTrap::setMaxEnergy(100);
	ClapTrap::setLevel(1);
	ClapTrap::setMeleeDmg(30);
	ClapTrap::setRangedDmg(20);
	ClapTrap::setArmorRed(5);
	ClapTrap::setName(name);
	std::cout << "Shiny " << name << " come to save Pandora, or Elpis, emm nevermind.\n";
}

FragTrap::FragTrap(FragTrap const & clap)
{
	*this = clap;
	std::cout << "Oh! My eye just switched back on!\n"
	<< "I see a tough-looking minion, and an incredibly handsome robot!\n";
}

FragTrap::~FragTrap()
{
	std::cout << "Only stairs can stop fearless " << getName() << ".\n";
}

void	FragTrap::meleeAttack(std::string const & target)
{
	std::cout << "Come closer you f#@k1ng p13$e of $h17!\n";
	ClapTrap::meleeAttack(target);
}

void	FragTrap::rangedAttack(std::string const & target)
{
	std::cout << "Here comes my big gun!\n";
	ClapTrap::rangedAttack(target);
}

static std::string	actionSkill(int i)
{
	std::string	skill[] = 
	{
		"Clap-In-The-Box",
		"Gun Wizard",
		"Torgue Fiesta",
		"Pirate Sip Mode",
		"One Shot Wonder",
		"Laser Inferno",
		"Miniontrap",
		"Meat Unicycle",
		"Funzerker",
		"Mechromagician",
		"Shhhh... Trap!",
		"Blight Bot",
		"Rubber Ducky",
		"Senseless Sacrifice",
		"Medbot"
	};
	return (skill[i]);
}

void	FragTrap::vaulthunter_dot_exe(std::string const & target)
{
	if (getEnergy() - 25 >= 0)
	{
		setEnergy(getEnergy() - 25);
		std::cout << getName() << " performing special ability " << actionSkill(rand() % 15) << '\n';
		std::cout << target << " prepare for your doom!\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << target << '\n';
	}
}

FragTrap &	FragTrap::operator=(FragTrap const & clap)
{
	std::cout << getName() << " need new copy of himself\n";
	ClapTrap::operator=(clap);
	return *this;
}
