/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 16:32:26 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 16:32:30 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_H
# define SCAVTRAP_H

#include <iostream>
#include "ClapTrap.hpp"

class ScavTrap : public ClapTrap
{

public:
	ScavTrap();
	ScavTrap(ScavTrap const & clap);
	ScavTrap(std::string const & name);
	~ScavTrap();

	void	meleeAttack(std::string const & target);
	void	rangedAttack(std::string const & target);
	void	challengeNewcomer(std::string const & target);

	ScavTrap &	operator=(ScavTrap const & clap);
	
};

#endif
