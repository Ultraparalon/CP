/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 17:15:28 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 17:15:29 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ClapTrap.hpp"

ClapTrap::ClapTrap() : _hp(100), _max_hp(100), _energy(100), _max_energy(100), _level(1), _melee_dmg(30), _ranged_dmg(20), _armor_red(5), _name("Clap Trap")
{
	std::cout << "Greetings traveler!\n";
	std::cout << "I am C L 4 P T P steward-bot.\n";
	std::cout << "You may call me by my localy designated name Clap Trap.\n";
}

ClapTrap::ClapTrap(std::string const & name) : _hp(100), _max_hp(100), _energy(100), _max_energy(100), _level(1), _melee_dmg(30), _ranged_dmg(20), _armor_red(5), _name(name)
{
	std::cout << "Shiny " << name << " come to save Pandora, or Elpis, emm nevermind.\n";
}

ClapTrap::ClapTrap(ClapTrap const & clap)
{
	*this = clap;
	std::cout << "Oh! My eye just switched back on!\n"
	<< "I see a tough-looking minion, and an incredibly handsome robot!\n";
}

ClapTrap::~ClapTrap()
{
	std::cout << "STAIRS?! NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO\n";
	std::cout << "Minion, you've gotta go on without me! Do your master " << _name << " proud!\n";
}

int			ClapTrap::getHp() const			{	return _hp;			}
int			ClapTrap::getMaxHp() const		{	return _max_hp;		}
int			ClapTrap::getEnergy() const		{	return _energy;		}
int			ClapTrap::getMaxEnergy() const	{	return _max_energy;	}
int			ClapTrap::getLevel() const		{	return _level;		}
int			ClapTrap::getMeleeDmg()	const	{	return _melee_dmg;	}
int			ClapTrap::getRangedDmg() const	{	return _ranged_dmg;	}
int			ClapTrap::getArmorRed()	const	{	return _armor_red;	}
std::string ClapTrap::getName() const		{	return _name;		}

void	ClapTrap::setHp(int const & val)			{	_hp = val;			}
void	ClapTrap::setMaxHp(int const & val) 		{	_max_hp = val;		}
void	ClapTrap::setEnergy(int const & val)		{	_energy = val;		}
void	ClapTrap::setMaxEnergy(int const & val)		{	_max_energy = val;	}
void	ClapTrap::setLevel(int const & val)			{	_level = val;		}
void	ClapTrap::setMeleeDmg(int const & val)		{	_melee_dmg = val;	}
void	ClapTrap::setRangedDmg(int const & val)		{	_ranged_dmg = val;	}
void	ClapTrap::setArmorRed(int const & val)		{	_armor_red = val;	}
void	ClapTrap::setName(std::string const & str)	{	_name = str;		}

void	ClapTrap::takeDamage(unsigned int amount)
{
	if ((int)amount > _armor_red)
	{
		_hp = (_hp - (int)amount >= 0) ? _hp - amount : 0;
		std::cout << "Ouch, thats hurts!\n";
		std::cout << "I feel pain of " << amount << "hp loss.\n";
		std::cout << "If your think that robots can't feel pain,\n";
		std::cout << "they actualy do, but in slowmotion.\n";
	}
	else
	{
		std::cout << "Mhahaha you cant't hurt me loser!\n";
	}
	
}

void	ClapTrap::beRepaired(unsigned int amount)
{
	_hp += amount;
	_hp = (_max_hp > _hp) ? _hp : _max_hp;
	_energy += amount;
	_energy = (_max_energy > _energy) ? _energy : _max_energy;
	std::cout << _name << " restored his hp to " << _hp << " and energy to "
	<< _energy << " and ready to fight\n";
}

void	ClapTrap::rangedAttack(std::string const & target)
{
	std::cout << _name << " attacks " << target << " at range, causing "
	<< _ranged_dmg << " points of damage!\n";
}

void	ClapTrap::meleeAttack(std::string const & target)
{
	std::cout << _name << " attacks " << target << " with melee attack, causing "
	<< _melee_dmg << " points of damage!\n";
}

void	ClapTrap::displayStatus()
{
	std::cout << "\n     Name: " << _name << '\n';
	std::cout << "       Hp: " << _hp << '\n';
	std::cout << "    MaxHp: " << _max_hp << '\n';
	std::cout << "   Energy: " << _energy << '\n';
	std::cout << "MaxEnergy: " << _max_energy << '\n';
	std::cout << "    Level: " << _level << '\n';
	std::cout << "    Melee: " << _melee_dmg << '\n';
	std::cout << "   Ranged: " << _ranged_dmg << '\n';
	std::cout << "    Armor: " << _armor_red << "\n\n";
	std::cout << "oomc oomc oomc, oh check me out, I'm dancing, I'm dancing!\n\n";
}

ClapTrap &	ClapTrap::operator=(ClapTrap const & clap)
{
	std::cout << "Phasecoping...\n";
	std::cout << "boop boop bup\n";
	std::cout << "Phasecopy ready\n";
	this->_hp = clap.getHp();
	this->_max_hp = clap.getMaxHp();
	this->_energy = clap.getEnergy();
	this->_max_energy = clap.getMaxEnergy();
	this->_level = clap.getLevel();
	this->_melee_dmg = clap.getMeleeDmg();
	this->_ranged_dmg = clap.getRangedDmg();
	this->_armor_red = clap.getArmorRed();
	this->_name = clap.getName();
	return *this;
}
