/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 12:25:01 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 12:25:02 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRAGTRAP_H
# define FRAGTRAP_H

#include <iostream>
#include "ClapTrap.hpp"

class FragTrap : public ClapTrap
{

public:
	FragTrap();
	FragTrap(FragTrap const & clap);
	FragTrap(std::string const & name);
	~FragTrap();

	void	meleeAttack(std::string const & target);
	void	rangedAttack(std::string const & target);
	void	vaulthunter_dot_exe(std::string const & target);

	FragTrap &	operator=(FragTrap const & clap);

};

#endif
