/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 16:32:17 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 16:32:19 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ScavTrap.hpp"

ScavTrap::ScavTrap() : _hp(100), _max_hp(100), _energy(50), _max_energy(50), _level(1), _melee_dmg(20), _ranged_dmg(15), _armor_red(3), _name("Scav Trap")
{
	std::cout << "Greetings traveler!\n";
	std::cout << "I am C L 4 P T P steward-bot.\n";
	std::cout << "You may call me by my localy designated name Scav Trap.\n";
}

ScavTrap::ScavTrap(std::string const & name) : _hp(100), _max_hp(100), _energy(50), _max_energy(50), _level(1), _melee_dmg(20), _ranged_dmg(15), _armor_red(3), _name(name)
{
	std::cout << "Shiny " << name << " is waiting for challange.\n";
}

ScavTrap::ScavTrap(ScavTrap const & clap)
{
	*this = clap;
	std::cout << "Oh! My eye just switched back on!\n"
	<< "I see a tough-looking minion, and an incredibly handsome robot!\n";
}

ScavTrap::~ScavTrap()
{
	std::cout << "No challenges left here, " << _name << " need to go.\n";
}

int			ScavTrap::getHp() const			{	return _hp;			}
int			ScavTrap::getMaxHp() const		{	return _max_hp;		}
int			ScavTrap::getEnergy() const		{	return _energy;		}
int			ScavTrap::getMaxEnergy() const	{	return _max_energy;	}
int			ScavTrap::getLevel() const		{	return _level;		}
int			ScavTrap::getMeleeDmg()	const	{	return _melee_dmg;	}
int			ScavTrap::getRangedDmg() const	{	return _ranged_dmg;	}
int			ScavTrap::getArmorRed()	const	{	return _armor_red;	}
std::string ScavTrap::getName() const		{	return _name;		}

void	ScavTrap::takeDamage(unsigned int amount)
{
	if ((int)amount > _armor_red)
	{
		_hp = (_hp - (int)amount >= 0) ? _hp - amount : 0;
		std::cout << "Ouch, thats hurts!\n";
		std::cout << "I feel pain of " << amount << "hp loss.\n";
		std::cout << "If your think that robots can't feel pain,\n";
		std::cout << "they actualy do, but in slowmotion.\n";
	}
	else
	{
		std::cout << "Mhahaha you cant't hurt me loser!\n";
	}
	
}

void	ScavTrap::beRepaired(unsigned int amount)
{
	_hp += amount;
	_hp = (_max_hp > _hp) ? _hp : _max_hp;
	_energy += amount;
	_energy = (_max_energy > _energy) ? _energy : _max_energy;
	std::cout << _name << " restored his hp to " << _hp << " and energy to "
	<< _energy << " and ready to fight\n";
}

void	ScavTrap::rangedAttack(std::string const & target)
{
	std::cout << _name << " attacks " << target << " with wub wub wub sounds, causing "
	<< _ranged_dmg << " points of damage!\n";
}

void	ScavTrap::meleeAttack(std::string const & target)
{
	std::cout << _name << " attacks " << target << " with melee attack,\n";
	std::cout << "and performing dance, because robots love to dance,\noh yeah, almost forgot, also causing "
	<< _melee_dmg << " points of damage!\n";
}

static std::string	challenge(int i)
{
	std::string	skill[] = 
	{
		"collect 139,377 brown rocks",
		"defeat Ug-Thak, Lord of Skags",
		"pilfer lost staff of Mount Schuler",
		"defeat Destroyer of Worlds",
		"dance, dance, baby",
		"find a life",
		"find claptrap's secret stash"
	};
	return (skill[i]);
}

void	ScavTrap::challengeNewcomer(std::string const & target)
{
	if (_energy - 25 >= 0)
	{
		_energy -= 25;
		std::cout << _name << " have a new challenge: " << challenge(rand() % 7) << '\n';
		std::cout << target << " are you ready for this?\n";
	}
	else
	{
		std::cout << "Not enough energy!\n";
		std::cout << "At least I can give you five... " << target << '\n';
	}

}

void	ScavTrap::displayStatus()
{
	std::cout << "\n     Name: " << _name << '\n';
	std::cout << "       Hp: " << _hp << '\n';
	std::cout << "    MaxHp: " << _max_hp << '\n';
	std::cout << "   Energy: " << _energy << '\n';
	std::cout << "MaxEnergy: " << _max_energy << '\n';
	std::cout << "    Level: " << _level << '\n';
	std::cout << "    Melee: " << _melee_dmg << '\n';
	std::cout << "   Ranged: " << _ranged_dmg << '\n';
	std::cout << "    Armor: " << _armor_red << "\n\n";
	std::cout << "oomc oomc oomc, oh check me out, I'm dancing, I'm dancing!\n\n";
}

ScavTrap &	ScavTrap::operator=(ScavTrap const & clap)
{
	std::cout << "Phasecoping...\n";
	std::cout << "boop boop bup\n";
	std::cout << "Phasecopy ready\n";
	this->_hp = clap.getHp();
	this->_max_hp = clap.getMaxHp();
	this->_energy = clap.getEnergy();
	this->_max_energy = clap.getMaxEnergy();
	this->_level = clap.getLevel();
	this->_melee_dmg = clap.getMeleeDmg();
	this->_ranged_dmg = clap.getRangedDmg();
	this->_armor_red = clap.getArmorRed();
	this->_name = clap.getName();
	return *this;
}
