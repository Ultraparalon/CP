/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/04 16:32:26 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/04 16:32:30 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_H
# define SCAVTRAP_H

#include <iostream>

class ScavTrap
{
	int _hp;
	int	_max_hp;
	int _energy;
	int	_max_energy;
	int	_level;
	int	_melee_dmg;
	int	_ranged_dmg;
	int	_armor_red;
	std::string	_name;

public:
	ScavTrap();
	ScavTrap(ScavTrap const & clap);
	ScavTrap(std::string const & name);
	~ScavTrap();

	int	getHp() const;
	int	getMaxHp() const;
	int	getEnergy() const;
	int	getMaxEnergy() const;
	int	getLevel() const;
	int	getMeleeDmg() const;
	int	getRangedDmg() const;
	int	getArmorRed() const;
	std::string	getName() const;

	void	takeDamage(unsigned int amount);
	void	beRepaired(unsigned int amount);

	void	rangedAttack(std::string const & target);
	void	meleeAttack(std::string const & target);
	void	challengeNewcomer(std::string const & target);
	void	displayStatus();

	ScavTrap &	operator=(ScavTrap const & clap);
	
};

#endif
