/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Convert.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/09 21:44:49 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/09 21:44:51 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Convert.hpp"

Convert::Convert() : _str("default") {}
Convert::Convert(std::string const & str) : _str(str) {}
Convert::Convert(Convert const & obj)	{	*this = obj;	}
Convert::~Convert() {}

std::string	Convert::getString() const	{	return _str;	}

int	Convert::toChar()
{
	try
	{
		return std::stoi(_str);
	}
	catch (std::exception & e)
	{
		throw Convert::ImpossibleException();
	}
}

int	Convert::toInt()
{
	try
	{
		return std::stoi(_str);
	}
	catch (std::exception & e)
	{
		throw Convert::ImpossibleException();
	}
}

float	Convert::toFloat()
{
	try
	{
		return std::stof(_str);
	}
	catch (std::exception & e)
	{
		throw Convert::ImpossibleException();
	}	
}

double	Convert::toDouble()
{
	try
	{
		return std::stod(_str);
	}
	catch (std::exception & e)
	{
		throw Convert::ImpossibleException();
	}	
}

Convert &	Convert::operator=(Convert const & obj)
{
	_str = obj.getString();
	return *this;
}

// ImpossibleException---------------------------------------------------

Convert::ImpossibleException::ImpossibleException() throw() {}
Convert::ImpossibleException::ImpossibleException(ImpossibleException const & obj) throw()
{
	*this = obj;
}
Convert::ImpossibleException::~ImpossibleException() throw() {}
const char *	Convert::ImpossibleException::what() const throw()
{
	return "impossible";
}
Convert::ImpossibleException &	Convert::ImpossibleException::operator=(ImpossibleException const &) throw()
{
	return *this;
}
