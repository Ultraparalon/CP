/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Convert.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/09 21:44:43 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/09 21:44:44 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONVERT_H
# define CONVERT_H

#include <iostream>

class Convert
{
	std::string	_str;

public:
	Convert();
	Convert(std::string const &);
	Convert(Convert const &);
	~Convert();

	std::string	getString() const;

	int		toChar();
	int		toInt();
	float	toFloat();
	double	toDouble();

	Convert & operator=(Convert const &);

	class ImpossibleException
	{
	public:
		ImpossibleException() throw();
		ImpossibleException(ImpossibleException const &) throw();
		virtual ~ImpossibleException() throw();
		virtual const char*	what() const throw();
		ImpossibleException &	operator=(ImpossibleException const &) throw();
		
	};
	
};

#endif
