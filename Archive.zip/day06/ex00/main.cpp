/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/09 20:32:06 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/09 20:32:10 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <iomanip>
#include <cmath>
#include "Convert.hpp"

void	convertion(std::string str)
{
	Convert 	convy(str);

	std::cout << "char: ";
	try
	{
		if (convy.toChar() < 33 || convy.toChar() > 126)
			std::cout << "Non displayable\n";
		else
			std::cout << static_cast<char>(convy.toChar()) << std::endl;
	}
	catch (Convert::ImpossibleException & e)
	{
		std::cout << e.what() << std::endl;
	}

	std::cout << "int: ";
	try
	{
		std::cout << convy.toInt() << std::endl;
	}
	catch(Convert::ImpossibleException & e)
	{
		std::cout << e.what() << std::endl;
	}

	std::cout << "float: ";
	try
	{
		if (convy.toFloat() - floor(convy.toFloat()))
			std::cout << convy.toFloat() << "f" << std::endl;
		else
			std::cout << convy.toFloat() << ".0f" << std::endl;
	}
	catch(Convert::ImpossibleException & e)
	{
		std::cout << e.what() << std::endl;
	}

	std::cout << "double: ";
	try
	{
		if (convy.toDouble() - floor(convy.toDouble()))
			std::cout << convy.toDouble() << std::endl;
		else
			std::cout << convy.toDouble() << ".0" << std::endl;

	}
	catch(Convert::ImpossibleException & e)
	{
		std::cout << e.what() << std::endl;
	}
}

int main(int argc, char** argv)
{
	if (argc != 2)
	{
		std::cout << "Usage: convert [param]\n";
	}
	else
	{
		convertion(argv[1]);
	}
	return 0;
}
