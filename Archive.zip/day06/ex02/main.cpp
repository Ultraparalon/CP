/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/10 18:17:02 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/10 18:17:05 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Base.hpp"
#include "A.hpp"
#include "B.hpp"
#include "C.hpp"

Base *	generate()
{
	int x = rand() % 3;
	if (x == 1)
	{
		std::cout << "A class generated.\n";
		return new A;
	}
	if (x == 2)
	{
		std::cout << "B class generated.\n";
		return new B;
	}
	std::cout << "C class generated.\n";
	return new C;
}

void	identify_from_pointer(Base * p)
{
	if (dynamic_cast<A*>(p))
		std::cout << "It's A class pointer\n";
	else if (dynamic_cast<B*>(p))
		std::cout << "It's B class pointer\n";
	else if (dynamic_cast<C*>(p))
		std::cout << "It's C class pointer\n";
}

void	identify_from_reference(Base & p)
{
	if (dynamic_cast<A*>(&p))
		std::cout << "It's A class reference\n";
	else if (dynamic_cast<B*>(&p))
		std::cout << "It's B class reference\n";
	else if (dynamic_cast<C*>(&p))
		std::cout << "It's C class reference\n";
}

int	main()
{
	srand(time(0));

	Base * test = generate();

	identify_from_pointer(test);
	identify_from_reference(*test);

	delete test;

	return 0;
}
