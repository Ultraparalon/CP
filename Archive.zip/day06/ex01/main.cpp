/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/10 14:16:49 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/10 14:16:50 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctime>
#include <cstdlib>
#include <iostream>

struct Data
{
	std::string	str1;
	int			val;
	std::string	str2;	
};

void *	serialize(void)
{
	char * data = new char[20];
	char * ret = data;

	for (int i = 0; i < 8; i++)
		*data++ = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[rand() % 62];

	int num = rand();
	*(reinterpret_cast<int *>(&(*data))) = num;

	data += 4;

	for (int i = 0; i < 8; i++)
		*data++ = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[rand() % 62];
	
	*data = '\0';

	data = ret;
	std::cout << "String 1: ";
	for (int i = 0; i < 8; i++)
		std::cout << *data++;
	std::cout << std::endl;
	std::cout << "Number:   " << num << std::endl;
	data += 4;
	std::cout << "String 2: " << data << std::endl;

	return (reinterpret_cast<void*>(ret));
}

Data *	deserialize(void * raw)
{
	Data * data = new Data;
	data->str1.assign(reinterpret_cast<char *>(raw), 8);
	data->val = *reinterpret_cast<int *>(&reinterpret_cast<char *>(raw)[8]);
	data->str2.assign(&reinterpret_cast<char *>(raw)[12], 8);

	return data;
}

int main()
{
	srand(time(0));

	void * raw = serialize();
	std::cout << "---------------------------\n";
	Data * data = deserialize(raw);

	std::cout << "String 1: " << data->str1 << std::endl;
	std::cout << "Number:   " << data->val << std::endl;
	std::cout << "String 2: " << data->str2 << std::endl;

	char * del = reinterpret_cast<char *>(raw);

	delete del;
	delete data;

	return 0;
}
