/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Brain.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 18:32:55 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 18:32:57 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	BRAIN_HPP
# define BRAIN_HPP

#include <string>
#include <sstream>

class Brain {

private:
	std::stringstream address;
	
public:
	Brain();
	~Brain();

	std::string identify();
	
};

#endif
