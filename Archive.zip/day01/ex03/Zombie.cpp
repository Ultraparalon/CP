/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:20:52 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:20:54 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

Zombie::Zombie(void) : name("default"), type("default") {}

Zombie::Zombie(std::string name, std::string type) : name(name), type(type)
{
	announce();
}

Zombie::~Zombie(void)
{
	std::cout << "Zombie named '" << this->name
	<< "' type of '" << this->type
	<< "' finaly got eternal rest.\n";
}

void	Zombie::announce(void)
{
	std::cout << "Zombie named '" << name
	<< "' type of '" << type << "' say: Braaaaiinzzzz...\n\n";
}

void	Zombie::setName(std::string new_name)
{
	name = new_name;
}

void	Zombie::setType(std::string new_type)
{
	type = new_type;
}
