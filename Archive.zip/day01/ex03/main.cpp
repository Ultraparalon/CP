/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 16:07:58 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 16:08:00 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cstdlib>
#include "Zombie.hpp"
#include "ZombieHorde.hpp"

int main(int argc, char **argv)
{
	int size;

	if (argc == 2)
	{
		if ((size = atoi(argv[1])) < 1)
			size = 42;
	}
	else
		size = 42;

	ZombieHorde party = ZombieHorde(size);

	party.announce();

	return (0);
}
