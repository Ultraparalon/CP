/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:21:03 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:21:05 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HPP
# define ZOMBIE_HPP

#include <iostream>
#include <string>

class Zombie {

private:
	std::string name;
	std::string type;

public:
	Zombie(void);
	Zombie(std::string name, std::string type);
	~Zombie(void);

	void	announce(void);
	void	setName(std::string new_name);
	void	setType(std::string new_type);
};

#endif
