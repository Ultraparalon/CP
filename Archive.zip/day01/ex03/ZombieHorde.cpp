/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieHorde.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 16:07:34 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 16:07:35 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ZombieHorde.hpp"

static std::string randname(void)
{
	int i = rand() % 9;

	switch (i) {
		case 1: return "Buddy";		break;
		case 2: return "Chompy";	break;
		case 3: return "Screamer";	break;
		case 4: return "Crawler";	break;
		case 5: return "Hammer";	break;
		case 6: return "Batman";	break;
		case 7: return "Peter";		break;
		case 8: return "Dave";		break;
		default: return "Nigga";
	}
}

ZombieHorde::ZombieHorde(int size) : size(size)
{
	this->horde = new Zombie[size];
	for (int i = 0; i < size; i++)
	{
		this->horde[i].setName(randname());
		this->horde[i].setType("Zombie Horde");
	}
}

ZombieHorde::~ZombieHorde(void)
{
	delete [] this->horde;
}

void	ZombieHorde::announce(void)
{
	for (int i = 0; i < this->size; i++)
	{
		this->horde[i].announce();
	}
}