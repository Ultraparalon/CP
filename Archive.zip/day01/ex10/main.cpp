/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 14:24:42 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 14:24:44 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>

void	read_input()
{
	std::string	buffer;

	while (!std::cin.eof())
	{
		std::cin >> buffer;
		std::cout << buffer << '\n';
	}
}

void	read_arg(std::string name)
{
	std::ifstream	ifs(name);
	std::string		buffer;
	std::string		content;

	if (ifs.is_open())
	{
		ifs.close();
		ifs.open(name, std::ifstream::out);
		if (!ifs)
		{
			std::cerr << "cat: " << name << ": Is a directory\n";
		}
		else
		{
			while (getline(ifs, buffer))
				content += buffer + "\n";

			std::cout << content;

			ifs.close();
		}
	}
	else
		std::cerr << "cat: " << name << ": No such file or directory\n";
}

int	main(int argc, char **argv)
{
	if (argc > 1)
	{
		while (*(++argv))
		{
			read_arg(*argv);
		}
	}
	else
	{
		read_input();
	}
	return (0);
}
