/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 19:51:47 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 19:51:49 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WEAPON_HPP
# define WEAPON_HPP

#include <string>

class Weapon {

private:
	std::string	type;

public:
	Weapon(std::string type);
	~Weapon();

	std::string	getType();
	void		setType(std::string newType);
	
};

#endif
