/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 10:27:38 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 10:27:40 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>
#include <cstring>

static bool	str_replace(std::string &content, std::string &str, std::string &replace)
{
	std::size_t pos = content.find(str);

	if (pos != std::string::npos)
	{
		content.replace(pos, str.length(), replace);
		return (true);
	}
	return (false);

}

static void	wizard(std::string filename, std::string s1, std::string s2)
{
	std::ifstream	ifs(filename);
	std::string		buffer;
	std::string		content;

	if (ifs.is_open())
	{
		std::ofstream	ofs(filename + ".replace");
		std::cout << "file '" << filename << "' opened\n";

		while (getline(ifs, buffer))
			content += buffer + "\n";
		ifs.close();

		while (str_replace(content, s1, s2));
		
		ofs << content << '\n';
		std::cout << "replacing successfuly done =^_^=\n";
		ofs.close();
	}
	else
		std::cout << "file doesn't exist\n";
}

int main(int argc, char **argv)
{
	(void)argv;
	if (argc == 4)
	{
		if (strlen(argv[1]) && strlen(argv[2]) && strlen(argv[3]))
			wizard(argv[1], argv[2], argv[3]);
		else
			std::cout << "empty parametr\n";
	}
	else
		std::cout << "usage: replase [file name] [replace] [with]\n";
	return (0);
}
