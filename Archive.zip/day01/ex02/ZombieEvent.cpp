/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieEvent.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:21:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:21:20 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ZombieEvent.hpp"

ZombieEvent::ZombieEvent() : type("default type") {}

ZombieEvent::ZombieEvent(std::string type) : type(type)
{
	std::cout << "New zombie event has begun.\n\n";
}

ZombieEvent::~ZombieEvent(void)
{
	std::cout << "Zombie event has become to its end.\n";
}

void	ZombieEvent::setZombieType(std::string new_type)
{
	this->type = new_type;
}

Zombie*	ZombieEvent::newZombie(std::string name)
{
	return (new Zombie(name, this->type));
}

static std::string randname(void)
{
	int i = rand() % 6;

	switch (i) {
		case 1: return "Buddy";		break;
		case 2: return "Chompy";	break;
		case 3: return "Screamer";	break;
		case 4: return "Crawler";	break;
		case 5: return "Hammer";	break;
		default: return "Nigga";
	}
}

Zombie*	ZombieEvent::randomChump(void)
{
	return (new Zombie(randname(), this->type));
}
