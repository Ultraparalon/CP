/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieEvent.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:21:33 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:21:35 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIEEVENT_HPP
# define ZOMBIEEVENT_HPP

# include <cstdlib>
# include "Zombie.hpp"

class ZombieEvent {

private:
	std::string type;

public:
	ZombieEvent();
	ZombieEvent(std::string type);
	~ZombieEvent(void);

	void	setZombieType(std::string new_type);
	Zombie	*newZombie(std::string name);
	Zombie	*randomChump(void);
};

#endif
