/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:21:44 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:21:46 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"
#include "ZombieEvent.hpp"

int main()
{
	Zombie stack_boi = Zombie("Boi", "Left4Dead");
	Zombie *heap_zombie1;
	Zombie *heap_zombie2;
	ZombieEvent walker = ZombieEvent("PlantsvsZombies");

	heap_zombie1 = walker.newZombie("Conehead");
	walker.setZombieType("Dying Light");
	heap_zombie2 = walker.randomChump();

	delete heap_zombie1;
	delete heap_zombie2;
	return (0);
}
