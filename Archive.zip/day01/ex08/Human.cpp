/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Human.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 12:07:51 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 12:07:58 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Human.hpp"

void	Human::meleeAttack(std::string const & target)
{
	std::cout << "Dealing melee attack to '" << target << "'.\n";
}

void	Human::rangedAttack(std::string const & target)
{
	std::cout << "Dealing ranged attack to '" << target << "'.\n";
}

void	Human::intimidatingShout(std::string const & target)
{
	std::cout << "Making intimidating shout adrresed to '" << target << "'.\n";
}

void	Human::action(std::string const & action_name, std::string const & target)
{
	void (Human::*func[])(std::string const &) =
	{
		&Human::meleeAttack,
		&Human::rangedAttack,
		&Human::intimidatingShout
	};

	std::string	fname[] = 
	{
		"meleeAttack",
		"rangedAttack",
		"intimidatingShout"
	};

	for (int i = 0; i < 3; i++)
	{
		if (fname[i] == action_name)
		{
			(this->*func[i])(target);
			break ;
		}
	}
}