/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 12:08:16 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 12:08:18 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Human.hpp"

int main()
{
	Human boi;

	boi.action("intimidatingShout", "Elf");
	boi.action("meleeAttack", "Orc");
	boi.action("rangedAttack", "Necromancer");
	boi.action("unknownAttack", "Human");

	return (0);
}
