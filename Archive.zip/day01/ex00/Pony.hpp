/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 11:34:09 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 11:34:10 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PONY_HPP
# define PONY_HPP

# include <iostream>
# include <string>

class Pony {
	
private:
	std::string	color;
	std::string	mane_color;
	std::string name;
	std::string feature;

public:
	Pony(std::string name, std::string color, std::string mane_color, std::string feature);
	~Pony(void);

	void	seePonyInfo(void);
};

#endif
