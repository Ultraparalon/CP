/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Pony.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 11:33:50 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 11:33:52 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Pony.hpp"

Pony::Pony(std::string name, std::string color, std::string mane_color, std::string feature)
{
	this->name = name;
	this->color = color;
	this->mane_color = mane_color;
	this->feature = feature;

	std::cout << "Majestic " << name << " come to this world, to proove that friendship is magic!\n\n";
}

Pony::~Pony(void)
{
	std::cout << this->name << " aprooved that friendship is magic.\n";
	std::cout << "And now she have to leave, to bring friendship in to other worlds!\n\n";
}

void	Pony::seePonyInfo(void)
{
	std::cout << "I am " << name << "!\n";
	std::cout << "I've come here to spread friendship!\n";
	std::cout << "My outstanding skills of " << feature << ", will help my on my way.\n";
	std::cout << "Also, my color is " << color << ", and I have beautiful " << mane_color << "-colored, mane.\n\n";
}
