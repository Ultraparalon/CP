/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 11:34:30 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 11:34:31 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Pony.hpp"

int	main()
{
	Pony rainbowDash = Pony("Raibow Dash", "blue", "rainbow", "weather control");
	Pony *pinkiePie = new Pony("Pinkie Pie", "pink", "lilac", "hyperactivity");

	rainbowDash.seePonyInfo();
	pinkiePie->seePonyInfo();

	std::cout << "It's time for all heap-pony to leave this world.\n\n";
	delete pinkiePie;

	std::cout << "It's time for all stack-pony to leave this world.\n\n";
	return (0);
}
