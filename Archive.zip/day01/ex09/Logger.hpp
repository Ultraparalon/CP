/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Logger.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:08:52 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:08:58 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LOGGER_HPP
# define LOGGER_HPP

# include <iostream>
# include <sstream>
# include <iomanip>
# include <ctime>
# include <fstream>

class Logger {

private:
	std::string	file;

	void		logToConsole(std::string const & log);
	void		logToFile(std::string const & log);
	std::string	makeLogEntry(std::string const & message);

public:
	Logger();
	Logger(std::string file);
	~Logger();

	void	log(std::string const & dest, std::string const & message);
	
};

#endif
