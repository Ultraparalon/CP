/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Logger.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:08:43 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:08:45 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Logger.hpp"

Logger::Logger() : file("defaultlog") {}
Logger::Logger(std::string file) : file(file) {}
Logger::~Logger() {}

void	Logger::logToConsole(std::string const & log)
{
	std::cout << log;
}

void	Logger::logToFile(std::string const & log)
{
	std::ofstream ofs(file, std::ios_base::app);

	ofs << log;
	ofs.close();
}

std::string Logger::makeLogEntry(std::string const & message)
{
	time_t				sec = time(NULL);
	struct tm 			*date = localtime(&sec);
	std::stringstream	tmp;
	std::string 		sdate;

	tmp << '[' << date->tm_year + 1900;
	tmp << '.' << std::setfill('0') << std::setw(2) << date->tm_mon + 1;
	tmp << '.' << std::setfill('0') << std::setw(2) << date->tm_mday;
	tmp << ' ';
	tmp << std::setfill('0') << std::setw(2) << date->tm_hour;
	tmp << ':' << std::setfill('0') << std::setw(2) << date->tm_min;
	tmp << ':' << std::setfill('0') << std::setw(2) << date->tm_sec;
	tmp << "] ";
	sdate += tmp.str();

	return (sdate + message + "\n");
}

void	Logger::log(std::string const & dest, std::string const & message)
{
	void	(Logger::*func[])(std::string const &) =
	{
		&Logger::logToConsole,
		&Logger::logToFile
	};

	std::string fname[] =
	{
		"logToConsole",
		"logToFile"
	};

	for (int i = 0; i < 2; i++)
	{
		if (fname[i] == dest)
		{
			(this->*func[i])(makeLogEntry(message));
			break ;
		}
	}
	
}
