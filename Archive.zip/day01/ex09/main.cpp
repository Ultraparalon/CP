/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/03 13:09:04 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/03 13:09:05 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Logger.hpp"

int main()
{
	Logger fancy_log = Logger("cool_log");

	fancy_log.log("logToConsole", "Sup console");
	fancy_log.log("logToFile", "Sup file");
	fancy_log.log("logToNowhere", "Sup anybody");

	fancy_log.log("logToConsole", "New console log entry");
	fancy_log.log("logToFile", "New file log entry");

	fancy_log.log("logToConsole", "Last console log entry");
	fancy_log.log("logToFile", "Last file log entry");

	return (0);
}
