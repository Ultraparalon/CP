/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   easyfind.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 17:24:20 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 17:24:22 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EASYFIND_H
# define EASYFIND_H

#include<exception>
#include<list>

template<typename T>
int	easyfind(T & list, int find)
{
	std::list<int>::const_iterator	it = list.begin();
	std::list<int>::const_iterator	ite = list.end();

	for (int i = 0; it != ite; it++, i++)
	{
		if (*it == find)
			return i; 
	}
	throw std::exception();
}

#endif
