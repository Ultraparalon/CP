/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 17:24:07 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 17:24:08 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <exception>
#include "easyfind.hpp"

int	main()
{
	std::list<int>	list;

	list.push_back(11);
	list.push_back(21);
	list.push_back(31);
	list.push_back(41);
	list.push_back(51);
	list.push_back(61);
	list.push_back(71);
	list.push_back(81);
	list.push_back(91);

	try
	{
		std::cout << "Value 71 at index: " << easyfind(list, 71) << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << "no such value(((" << std::endl;
	}
	std::cout << "------------------------\n";
	try
	{
		std::cout << "Value 99 at index: " << easyfind(list, 1) << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << "no such value(((" << std::endl;
	}

	std::cout << "Still working!\n";

	return (0);
}
