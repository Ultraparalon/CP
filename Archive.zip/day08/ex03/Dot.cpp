/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dot.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:47:21 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:47:22 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Dot.hpp"

Dot::Dot() : _type('.') {}
Dot::Dot(Dot const & obj)	{	*this = obj;	}
Dot::~Dot() {}

char	Dot::getType() const	{	return _type;	}

void	Dot::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)vec[i];
	std::cout << **arr;
}

Dot &	Dot::operator=(Dot const &)
{
	return *this;
}
