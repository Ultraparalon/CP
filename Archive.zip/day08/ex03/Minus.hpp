/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Minus.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:46:59 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:47:00 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINUS_H
# define MINUS_H

#include <vector>
#include "IFuck.hpp"

class Minus : public IFuck
{
	char	_type;
	
public:
	Minus();
	Minus(Minus const &);
	~Minus();
	
	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	Minus &	operator=(Minus const &);
};

#endif
