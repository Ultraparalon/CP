/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BracBefore.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:47:52 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:47:53 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BRACBEFORE_H
# define BRACBEFORE_H

#include <vector>
#include "BracAfter.hpp"
#include "IFuck.hpp"

class BracBefore : public IFuck
{
	char	_type;

public:
	BracBefore();
	BracBefore(BracBefore const &);
	~BracBefore();

	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	BracBefore &	operator=(BracBefore const &);
};

#endif
