/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BracAfter.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:48:07 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:48:08 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BRACAFTER_H
# define BRACAFTER_H

#include <vector>
#include "BracBefore.hpp"
#include "IFuck.hpp"

class BracAfter : public IFuck
{
	char	_type;

public:
	BracAfter();
	BracAfter(BracAfter const &);
	~BracAfter();

	char	getType() const;

	void	execute(std::vector<IFuck *> * , unsigned int &, char **) const;
	
	BracAfter &	operator=(BracAfter const &);
};

#endif
