/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BracAfter.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:48:03 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:48:04 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "BracAfter.hpp"

BracAfter::BracAfter() : _type(']') {}
BracAfter::BracAfter(BracAfter const & obj)	{	*this = obj;	}
BracAfter::~BracAfter() {}

char	BracAfter::getType() const	{	return _type;	}

void	BracAfter::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)arr;
    int brc = 0;
    if (**arr)
    {
	    if ((*vec)[i]->getType() == ']')
	        brc++;
	    while (brc)
	    {
	        --i;
	        if ((*vec)[i]->getType() == '[')
	            brc--;
	        if ((*vec)[i]->getType() == ']')
	            brc++;
	    }
	    --i;
	}
}

BracAfter &	BracAfter::operator=(BracAfter const &)
{
	return *this;
}
