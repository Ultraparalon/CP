/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Plus.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:46:49 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:46:51 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Plus.hpp"

Plus::Plus() : _type('+') {}
Plus::Plus(Plus const & obj)	{	*this = obj;	}
Plus::~Plus() {}

char	Plus::getType() const	{	return _type;	}

void	Plus::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)vec[i];
	(**arr)++;
}

Plus &	Plus::operator=(Plus const &)
{
	return *this;
}
