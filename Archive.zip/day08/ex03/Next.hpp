/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Next.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 18:46:41 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 18:46:42 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NEXT_H
# define NEXT_H

#include <vector>
#include "IFuck.hpp"

class Next : public IFuck
{
	char	_type;
	
public:
	Next();
	Next(Next const &);
	~Next();
	
	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	Next &	operator=(Next const &);
};

#endif
