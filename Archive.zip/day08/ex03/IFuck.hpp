/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   IFuck.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 18:37:49 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 18:37:51 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef IFUCK_H
# define IFUCK_H

#include <iostream>
#include <vector>

class IFuck
{
public:
	virtual	~IFuck() {}

	virtual char	getType() const = 0;

	virtual	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const = 0;
	
};

#endif
