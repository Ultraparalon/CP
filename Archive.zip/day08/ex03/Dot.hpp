/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dot.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:47:15 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:47:16 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DOT_H
# define DOT_H

#include <vector>
#include "IFuck.hpp"

class Dot : public IFuck
{
	char	_type;
	
public:
	Dot();
	Dot(Dot const &);
	~Dot();
	
	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	Dot &	operator=(Dot const &);
};

#endif
