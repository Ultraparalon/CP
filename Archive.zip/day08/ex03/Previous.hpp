/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Previous.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:46:03 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:46:04 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PREVIOUS_H
# define PREVIOUS_H

#include <vector>
#include "IFuck.hpp"

class Previous : public IFuck
{
	char	_type;
	
public:
	Previous();
	Previous(Previous const &);
	~Previous();
	
	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	Previous &	operator=(Previous const &);
};

#endif
