/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   BracBefore.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:47:55 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:47:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "BracBefore.hpp"

BracBefore::BracBefore() : _type('[') {}
BracBefore::BracBefore(BracBefore const & obj)	{	*this = obj;	}
BracBefore::~BracBefore() {}

char    BracBefore::getType() const  {   return _type;   }

void	BracBefore::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)arr;
    int brc = 1;
    if (!**arr)
        while (brc)
        {
            ++i;
            if ((*vec)[i]->getType() == '[')
                ++brc;
            if ((*vec)[i]->getType() == ']')
                --brc;
        }
}

BracBefore &	BracBefore::operator=(BracBefore const &)
{
	return *this;
}
