/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Minus.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:47:03 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:47:04 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Minus.hpp"

Minus::Minus() : _type('-') {}
Minus::Minus(Minus const & obj)	{	*this = obj;	}
Minus::~Minus() {}

char	Minus::getType() const	{	return _type;	}

void	Minus::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)vec[i];
	(**arr)--;
}

Minus &	Minus::operator=(Minus const &)
{
	return *this;
}
