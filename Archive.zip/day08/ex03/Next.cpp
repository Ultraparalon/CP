/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Next.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 18:46:33 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 18:46:34 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Next.hpp"

Next::Next() : _type('>') {}
Next::Next(Next const & obj)	{	*this = obj;	}
Next::~Next() {}

char	Next::getType() const	{	return _type;	}

void	Next::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)vec[i];
	(*arr)++;

}

Next &	Next::operator=(Next const &)
{
	return *this;
}
