/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Coma.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:50:11 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:50:12 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef COMA_H
# define COMA_H

#include <vector>
#include "IFuck.hpp"

class Coma : public IFuck
{
	char	_type;
	
public:
	Coma();
	Coma(Coma const &);
	~Coma();

	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	Coma &	operator=(Coma const &);
};

#endif
