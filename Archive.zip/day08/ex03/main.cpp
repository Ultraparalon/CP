/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 13:28:11 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 13:28:12 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>
#include <exception>
#include <vector>
#include "IFuck.hpp"
#include "Next.hpp"
#include "Previous.hpp"
#include "BracAfter.hpp"
#include "BracBefore.hpp"
#include "Coma.hpp"
#include "Dot.hpp"
#include "Minus.hpp"
#include "Plus.hpp"

using namespace std;

int main(int argc, char **argv) {
	if (argc != 2)
	{
		std::cout << "usage: fuckingfuck [filename]\n";
		return (0);
	}

    char * cpu = new char[30000];

    vector<IFuck *> acc;
    char ch;

    ifstream infile(argv[1]);
    while (infile) {
        infile.get(ch);
        if (ch == '>')
            acc.push_back(new Next);
        else if (ch == '<')
            acc.push_back(new Previous);
        else if (ch == '+')
            acc.push_back(new Plus);
        else if (ch == '-')
            acc.push_back(new Minus);
        else if (ch == '.')
            acc.push_back(new Dot);
        else if (ch == ',')
            acc.push_back(new Coma);
        else if (ch == '[')
            acc.push_back(new BracBefore);
        else if (ch == ']')
            acc.push_back(new BracAfter);
    }

    infile.close();

    try
    {
        for (unsigned int i = 0; i < acc.size(); i++)
        {
            acc[i]->execute(&acc, i, &cpu);
        }
    }
    catch (std::exception & e)
    {
        std::cout << e.what() << std::endl;
    }

    acc.clear();

    return (0);
}
