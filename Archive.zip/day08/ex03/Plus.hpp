/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Plus.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:46:33 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:46:34 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLUS_H
# define PLUS_H

#include <vector>
#include "IFuck.hpp"

class Plus : public IFuck
{
	char	_type;
	
public:
	Plus();
	Plus(Plus const &);
	~Plus();
	
	char	getType() const;

	void	execute(std::vector<IFuck *> *, unsigned int &, char **) const;
	
	Plus &	operator=(Plus const &);
};

#endif
