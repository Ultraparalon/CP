/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Previous.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:46:09 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:46:10 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Previous.hpp"

Previous::Previous() : _type('<') {}
Previous::Previous(Previous const & obj)	{	*this = obj;	}
Previous::~Previous() {}

char	Previous::getType() const	{	return _type;	}

void	Previous::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)vec[i];
	(*arr)--;

}

Previous &	Previous::operator=(Previous const &)
{
	return *this;
}
