/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Coma.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/12 19:50:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/12 19:50:20 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Coma.hpp"

Coma::Coma() : _type(',') {}
Coma::Coma(Coma const & obj)	{	*this = obj;	}
Coma::~Coma() {}

char	Coma::getType() const	{	return _type;	}

void	Coma::execute(std::vector<IFuck *> * vec, unsigned int & i, char **arr) const
{
	(void)vec[i];
	std::cin >> **arr;

}

Coma &	Coma::operator=(Coma const &)
{
	return *this;
}
