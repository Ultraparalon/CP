/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Span.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 19:42:27 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 19:42:28 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SPAN_H
# define SPAN_H

#include<iostream>
#include<vector>

class Span
{
	unsigned int		_size;
	std::vector<int>	_container;

public:
	Span();
	Span(unsigned int const &);
	Span(Span const &);
	~Span();

	void	addNumber(int);
	int		shortestSpan();
	int		longestSpan();

	void	show();

	Span &	operator=(Span const &);

	class OverflowException
	{
	public:
		OverflowException() throw();
		OverflowException(OverflowException const &) throw();
		virtual ~OverflowException() throw();
		virtual const char*	what() const throw();
		OverflowException &	operator=(OverflowException const &) throw();
		
	};

	class ShortException
	{
	public:
		ShortException() throw();
		ShortException(ShortException const &) throw();
		virtual ~ShortException() throw();
		virtual const char*	what() const throw();
		ShortException &	operator=(ShortException const &) throw();
		
	};

	class LongException
	{
	public:
		LongException() throw();
		LongException(LongException const &) throw();
		virtual ~LongException() throw();
		virtual const char*	what() const throw();
		LongException &	operator=(LongException const &) throw();
		
	};
	
};

#endif
