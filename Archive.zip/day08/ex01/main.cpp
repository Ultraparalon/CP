/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 19:42:34 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 19:42:35 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Span.hpp"

int main()
{
	Span span(10);

	try
	{
		span.addNumber(5);
		span.addNumber(15);
		span.addNumber(25);
		span.addNumber(35);
		span.addNumber(45);
		span.addNumber(55);
		span.addNumber(65);
		span.addNumber(75);
		span.addNumber(85);
		span.addNumber(95);
		span.addNumber(105);
	}
	catch (Span::OverflowException & e)
	{
		std::cout << e.what() << std::endl;
	}

	std::cout << "----------------\n";
	span.show();
	std::cout << "----------------\n";

	std::cout << span.shortestSpan() << std::endl;
	std::cout << span.longestSpan() << std::endl;
	std::cout << "----------------\n";

	Span test = Span(0);

	try
	{
		test.addNumber(999);
	}
	catch (Span::OverflowException & e)
	{
		std::cout << e.what() << std::endl;
	}

	try
	{
		std::cout << test.shortestSpan() << std::endl;
	}
	catch (Span::ShortException & e)
	{
		std::cout << e.what() << std::endl;
	}

	try
	{
		std::cout << test.longestSpan() << std::endl;
	}
	catch (Span::LongException & e)
	{
		std::cout << e.what() << std::endl;
	}

// Span sp = Span(5);
// sp.addNumber(5);
// sp.addNumber(3);
// sp.addNumber(17);
// sp.addNumber(9);
// sp.addNumber(11);
// std::cout << sp.shortestSpan() << std::endl;
// std::cout << sp.longestSpan() << std::endl;

	return 0;
}
