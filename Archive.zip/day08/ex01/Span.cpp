/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Span.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 19:42:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 19:42:20 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Span.hpp"

Span::Span() : _size(0) {}
Span::Span(unsigned int const & size) : _size(size) {}
Span::Span(Span const & obj)	{	*this = obj;	}
Span::~Span() {}

void	Span::addNumber(int val)
{
	if (_size <= _container.size())
		throw Span::OverflowException();
	else
		_container.push_back(val);

}

int	Span::shortestSpan()
{
	if (_container.size() <= 1)
		throw Span::ShortException();

	std::vector<int>::iterator 	it = _container.begin();
	int ret = *it;
	for (unsigned int i = 0; i < _container.size(); i++, it++)
	{
		if (*it < ret)
			ret = *it;
	}
	return ret;
}

int	Span::longestSpan()
{
	if (_container.size() <= 1)
		throw Span::LongException();

	std::vector<int>::iterator 	it = _container.begin();
	int ret = *it;
	for (unsigned int i = 0; i < _container.size(); i++, it++)
	{
		if (*it > ret)
			ret = *it;
	}
	return ret;
}

void	Span::show()
{
	std::vector<int>::iterator 	it = _container.begin();
	for (unsigned int i = 0; i < _container.size(); i++, it++)
	{
		std::cout << "vector: " << *it << std::endl;
	}
}

Span &	Span::operator=(Span const & obj)
{
	_size = obj._size;
	_container.clear();
	std::vector<int>::const_iterator 	it = obj._container.begin();
	for (unsigned int i = 0; i < obj._container.size(); i++, it++)
	{
		_container.push_back(*it);
	}
	return *this;
}

// OverflowException---------------------------------------------------

Span::OverflowException::OverflowException() throw() {}
Span::OverflowException::OverflowException(OverflowException const & obj) throw()
{
	*this = obj;
}
Span::OverflowException::~OverflowException() throw() {}
const char *	Span::OverflowException::what() const throw()
{
	return "Stack is full!";
}
Span::OverflowException &	Span::OverflowException::operator=(OverflowException const &) throw()
{
	return *this;
}

// ShortException---------------------------------------------------

Span::ShortException::ShortException() throw() {}
Span::ShortException::ShortException(ShortException const & obj) throw()
{
	*this = obj;
}
Span::ShortException::~ShortException() throw() {}
const char *	Span::ShortException::what() const throw()
{
	return "(short)Nothing to return!";
}
Span::ShortException &	Span::ShortException::operator=(ShortException const &) throw()
{
	return *this;
}

// LongException---------------------------------------------------

Span::LongException::LongException() throw() {}
Span::LongException::LongException(LongException const & obj) throw()
{
	*this = obj;
}
Span::LongException::~LongException() throw() {}
const char *	Span::LongException::what() const throw()
{
	return "(long)Nothing to return!";
}
Span::LongException &	Span::LongException::operator=(LongException const &) throw()
{
	return *this;
}
