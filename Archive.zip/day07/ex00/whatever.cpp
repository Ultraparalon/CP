/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   whatever.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/10 20:25:38 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/10 20:25:44 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

template <typename T>
void	swap(T & x, T & y)
{
	T z;
	z = x;
	x = y;
	y = z;
}

template <typename T>
T &	min(T & x, T & y)
{
	return (x < y) ? x : y;
}

template <typename T>
T &	max(T & x, T & y)
{
	return (x > y) ? x : y;
}


int	main()
{
	int a = 2;
int b = 3;
::swap( a, b );
std::cout << "a = " << a << ", b = " << b << std::endl;
std::cout << "min( a, b ) = " << ::min( a, b ) << std::endl;
std::cout << "max( a, b ) = " << ::max( a, b ) << std::endl;
std::string c = "chaine1";
std::string d = "chaine2";
::swap(c, d);
std::cout << "c = " << c << ", d = " << d << std::endl;
std::cout << "min( c, d ) = " << ::min( c, d ) << std::endl;
std::cout << "max( c, d ) = " << ::max( c, d ) << std::endl;
return 0;
	// int x = 50;
	// int y = 100;

	// swap(x, y);

	// std::cout << "X: " << x << std::endl;
	// std::cout << "Y: " << y << std::endl;

	// std::cout << "lowest: " << min(x, y) << std::endl;
	// std::cout << "highest: " << max(x, y) << std::endl;
	// //equality test------------------------

	// x = 50;

	// std::cout << "X: " << x << std::endl;
	// std::cout << "Y: " << y << std::endl;

	// max(x, y) = 999;

	// std::cout << "X: " << x << std::endl;
	// std::cout << "Y: " << y << std::endl;

	return 0;
}
