/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   iter.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 12:06:48 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 12:06:50 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

template<typename T>
void	show(T & val)
{
	std::cout << val << std::endl;
}

template<typename T>
void	iter(T *addr, unsigned int	len, void (*function)(T &))
{
	while (len--)
	{
		function(*addr++);
	}
}

int main()
{
	char carr[] = "test!";
	iter(carr, 5, &show);
	std::cout << "--------------------------------\n";
	int irra[] = { 1, 2, 3, 4, 5, 6, 7, 8 };
	iter(irra, 8, &show);
	std::cout << "--------------------------------\n";
	std::string str[] = {"lol", "kek", "chebureck"};
	iter(str, 3, &show);

	return 0;
}
