/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Array.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 15:50:48 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 15:50:50 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	ARRAY_H
# define ARRAY_H

#include<iostream>
#include<exception>

template<typename T>
class Array
{
	T *				_array;
	unsigned int	_n;

public:
	Array() : _array(NULL), _n(0) {}
	Array(unsigned int n)
	{
		_n = n;
		_array = new T[n];
	}
	Array(Array const & obj) 
	{
		*this = obj;
	}
	~Array() {}

	unsigned int size() const
	{
		return _n;
	}

	T &	operator=(Array const &r)
	{
		this->_n = r._n;
		delete[] this->_array;
		_array = new T[_n];

		for (unsigned int i = 0; i < _n; i++)
			_array[i] = r._array[i];
	}

	T &	operator[](unsigned int n)
	{
		if (n < this->_n)
			return _array[n];
		throw std::exception();
	}
	
};

#endif
