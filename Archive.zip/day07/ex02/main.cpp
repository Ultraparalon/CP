/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/11 16:04:31 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/11 16:04:33 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Array.hpp"

int main()
{
	srand(time(0));

	unsigned int n = rand() % 50;
	Array<int> test(n);

	std::cout << "Size of Array: " << test.size() << std::endl << std::endl;

	try
	{
		for (unsigned int i = 0; i < test.size(); i++)
			test[i] = rand();

		for (unsigned int i = 0; i <= test.size(); i++)
		{
			std::cout << "Array[" << i << "] Content: " << test[i] << std::endl;
		}
	}
	catch (std::exception &e)
	{
		std::cout << e.what() << std::endl;
	}

	std::cout << "Still working!!!\n";
}
