/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Player.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:15:41 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:15:44 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Player.hpp"

Player::Player() : Ship()
{
	setScore(0);
}

Player::Player(const char* name) : Ship(10, 10, 1, 3, name)
{
	setScore(0);
}

Player::~Player() {}

Player::Player(Player const & src)
{
	*this = src;
}

Player & Player::operator=(Player const & rhs)
{
	_score = rhs.getScore();

	return *this;
}

unsigned int Player::getScore() const
{
	return _score;
}

void Player::setScore(unsigned int score)
{
	_score = score;
}

void	Player::addScore(unsigned int val)
{
	_score += val;
}

bool	Player::hit(int y, int x)
{
	if (collision(y, x))
	{
		setHp(getHp() - 1);
		return true;
	}
	return (false);
}
