/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:16:54 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:16:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ncurses.h>
#include <iostream>
#include "Moves.hpp"

void    resurect(Enemy * enemys, int val)
{
    int luck = rand() % val;
    if (!enemys[luck].getStatus())
    {
        int size = enemys[luck].getSize();
        enemys[luck].setStatus(true);
        enemys[luck].setX(99 - size);
        enemys[luck].setHp(size * size * size);
        enemys[luck].setY(rand() % 49 + 1);
    }
}

void settings()
{
    Window window;
    window.initNcurses();
    window.initColors();
    window.drawBorders();

    Player player = Player();
    Bullet bullets[100];
    Enemy  enemys[] = {
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "X"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "3"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "X"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "<"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "G"),
        Enemy(rand() % 49 + 1, 99, 1, 1, "8"),
        Enemy(rand() % 49 + 1, 98, 2, 5, "@"),
        Enemy(rand() % 49 + 1, 98, 2, 5, "@"),
        Enemy(rand() % 49 + 1, 97, 3, 15, "#")
    };

    Enemy  scrap[] = {
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "*"),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "o"),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "*"),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "o"),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "*"),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, "."),
        Enemy(rand() % 49 + 1, rand() % 99, 1, 1, ".")
    };


    Moves moves = Moves();
    nodelay(stdscr, true);

    for (;;)
    {
        resurect(enemys, 15);
        resurect(scrap, 30);
        window.clear();
        moves.globalMoves(bullets, player, enemys, scrap);
        refresh();
        usleep(25000);
        if (!player.getHp())
        {
            endwin();
            std::cout << "GG WP    Score: " << player.getScore() << std::endl;
            exit(0);
        }
    }
}

int main()
{
    srand(time(NULL));

    settings();

    return 0;
}
