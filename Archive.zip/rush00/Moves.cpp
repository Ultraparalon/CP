/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Moves.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:15:21 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:15:23 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Moves.hpp"

Moves::Moves() {}
Moves::Moves(Moves const & src) {   *this = src;    }
Moves::~Moves() {}

Moves & Moves::operator=(Moves const &) {
    return *this;
}

void Moves::playerMoves(Player & player, bool &space)
{
    int ch = getch();

    if (ch == 'a')
        player.moveLeft();
    else if (ch == 'd')
        player.moveRight();
    else if (ch == 'w')
        player.moveUp();
    else if (ch == 's')
        player.moveDown();
    else if (ch == ' ')
        space = true;
    else if (ch == 'p')
    {
        mvwprintw(stdscr, 25, 45, "PAUSED");
        while (getch() != 'p') ;
    }
    else if (ch == 'q')
    {
        endwin();
        std::cout << "Game over" << std::endl;
        exit(0);
    }

    wattron(stdscr, COLOR_PAIR(10));
    mvprintw(player.getY(), player.getX(), "}", 10);
}

static void	navigation(Player &player)
{
    static int sec = time(0);

    attron(COLOR_PAIR(4));
    mvwprintw(stdscr, 5, mapX + 8, "Score: %d ", player.getScore());
    mvwprintw(stdscr, 6, mapX + 8, "Time:  %d ", time(0) - sec);
    mvwprintw(stdscr, 7, mapX + 8, "Lives: %d ", player.getHp());
    mvwprintw(stdscr, 15, mapX + 8, "Up:    W");
    mvwprintw(stdscr, 16, mapX + 8, "Down:  S");
    mvwprintw(stdscr, 17, mapX + 8, "Left:  A");
    mvwprintw(stdscr, 18, mapX + 8, "Right: D");
    mvwprintw(stdscr, 19, mapX + 8, "Shoot: SPACE");
    mvwprintw(stdscr, 21, mapX + 8, "Pause: P");
    mvwprintw(stdscr, 22, mapX + 8, "Quit:  Q");
    attroff(COLOR_PAIR(4));
}

static  void    enemyDraw(Enemy & enemy)
{
    int size = enemy.getSize();
    for (int i = 0; i < size; i++)
    {
        mvprintw(enemy.getY() + i, enemy.getX() + i, enemy.getType().c_str(), 0);
        mvprintw(enemy.getY() - i, enemy.getX() + i, enemy.getType().c_str(), 0);
        mvprintw(enemy.getY(), enemy.getX() + i, enemy.getType().c_str(), 0);
    }
}

void    Moves::globalMoves(Bullet * bullet, Player & player, Enemy * enemy, Enemy * scrap)
{
    bool space = false;

    for (int i = 0; i < 30; i++)
    {
        wattroff(stdscr, COLOR_PAIR(30));
        if (scrap[i].getX() <= 1)
            scrap[i].setStatus(false);
        if (scrap[i].getStatus())
        {
            enemyMove(scrap[i]);
            enemyDraw(scrap[i]);
        }
    }

    playerMoves(player, space);
    navigation(player);

    for (int i = 0; i < 100; i++) // bullets
    {
        if (space && bullet[i].getX() && bullet[i].getX() >= mapX)
        {
             bullet[i].setY(player.getY());
             bullet[i].setX(player.getX() + 1);
             bullet[i].setCourse(1);
             space = false;
        }
        if (bullet[i].getX() && bullet[i].getX() < mapX) // bullet exist
        {
            wattron(stdscr, COLOR_PAIR(40));
            mvprintw(bullet[i].getY(), bullet[i].getX(), "-");
            if (player.hit(bullet[i].getY(), bullet[i].getX()))
                bullet[i].setX(mapX);
            for (int en = 0; en < 15; en++) // enemy hit
            {
                if (enemy[en].getStatus())
                    if (enemy[en].hit(bullet[i].getY(), bullet[i].getX()))
                    {
                        bullet[i].setX(mapX);
                        player.addScore(10);
                    }
            }
            bullet[i].moveBullet();
        }

    }

    for (int i = 0; i < 15; i++) // enemy
    {
        wattron(stdscr, COLOR_PAIR(30));
        if (enemy[i].getX() <= 1)
            enemy[i].setStatus(false);
        if (enemy[i].getStatus())
        {
            enemyMove(enemy[i]);
            enemyDraw(enemy[i]);
            if (player.hit(enemy[i].getY(), enemy[i].getX()))
                enemy[i].setStatus(false);
            if (enemy[i].getSize() == 2 && !(rand() % 128)) //enemy shoot
            {
                for(int b = 0; b < 100; b++)
                {
                    if (bullet[b].getX() && bullet[b].getX() >= mapX)
                    {
                        bullet[b].setY(enemy[i].getY());
                        bullet[b].setX(enemy[i].getX() - 1);
                        bullet[b].setCourse(-2);
                        break ;
                    }
                }
            }
        }


    }
}

void    Moves::enemyMove(Enemy & enemy)
{
    int size = enemy.getSize();
    if (size == 1)
        enemy.moveLeft();
    else if (size == 2)
    {
        size = rand() % 32;
        if (!size && enemy.getY() > 3)
            enemy.moveUp();
        else if (size == 1 && enemy.getY() < 47)
            enemy.moveDown();
    }
    else
    {
        size = rand() % 128;
        if (size > 120)
            enemy.moveLeft();
        else if (size == 1 && enemy.getY() > 3)
            enemy.moveUp();
        else if (size == 2 && enemy.getY() < 47)
            enemy.moveDown();
        else if (size == 3 && enemy.getX() < 97)
            enemy.moveRight();
    }
}




