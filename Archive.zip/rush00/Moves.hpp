/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Moves.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:15:30 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:15:32 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MOVES_H
# define MOVES_H

#include <unistd.h>
#include "Window.hpp"
#include "Player.hpp"
#include "Enemy.hpp"
#include "Bullet.hpp"

class Moves
{

public:
    Moves();
    Moves(Moves const & src);
    ~Moves();
    Moves & operator=(Moves const & rhs);

    void playerMoves(Player &, bool &);
    void globalMoves(Bullet *, Player &, Enemy *, Enemy *);
    void	enemyMove(Enemy &);

};

#endif
