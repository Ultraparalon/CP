/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Enemy.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:14:47 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:14:50 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Enemy.hpp"

Enemy::Enemy() {}

Enemy::Enemy(int y, int x, int size, int hp, std::string who) : Ship(y, x, size, hp, who)
{
	_isAlive = true;
}

Enemy::~Enemy() {}

Enemy::Enemy(Enemy const & src)	{	*this = src;	}

Enemy & Enemy::operator=(Enemy const & rhs) {
	_isAlive = rhs.getStatus();
	return *this;
}

bool Enemy::getStatus() const
{
	return _isAlive;
}

void	Enemy::setStatus(bool b)
{
	_isAlive = b;
}

bool	Enemy::hit(int y, int x)
{
	if (collision(y, x))
	{
		setHp(getHp() - 1);
		if (!getHp())
			_isAlive = false;
		return true;
	}
	return false;
}
