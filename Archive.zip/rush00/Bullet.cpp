/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bullet.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:13:50 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:13:55 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bullet.hpp"

Bullet::Bullet() : _y(200), _x(200), _course(1) {}

Bullet::Bullet(int y, int x, int course) : _y(y), _x(x), _course(course) {}

Bullet::~Bullet() {}

Bullet::Bullet( Bullet const & src)	{	*this = src;	}

Bullet & Bullet::operator=(Bullet const & rhs)
{
    _y = rhs._y;
    _x = rhs._x;
    return *this;
}

void Bullet::setY(unsigned int sy)  {   _y = sy; }
void Bullet::setX(unsigned int sx)  {   _x = sx; }
void Bullet::setCourse(unsigned int val)  {   _course = val; }

unsigned int Bullet::getX() const   {   return _x;   }
unsigned int Bullet::getY() const   {   return _y;   }

void	Bullet::moveBullet()
{
	_x += _course;
}

