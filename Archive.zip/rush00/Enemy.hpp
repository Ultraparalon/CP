/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Enemy.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:14:59 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:15:00 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ENEMY_H
# define ENEMY_H

#include <iostream>
#include "Ship.hpp"

class Enemy : public Ship
{
	bool _isAlive;

public:
	Enemy();
	Enemy(int y, int x, int size, int hp, std::string who);
	~Enemy();
	Enemy(Enemy const & src);

	Enemy & operator=(Enemy const & rhs);
	
	bool getStatus() const;
	void	setStatus(bool);

	bool	hit(int, int);	

};

#endif
