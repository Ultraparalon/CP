/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ship.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:16:15 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:16:18 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SHIP_H
# define SHIP_H

#include <iostream>
#include <ncurses.h>

class Ship
{
	int	_y;
	int _x;
	int _size;
	int _hp;
	std::string _type;

public:
	Ship();
	Ship(int, int, int, int, std::string);
	~Ship();
	Ship( Ship const & src);

	Ship & operator=(Ship const & rhs);
	void shipMoved(int, int, const char*, short);

	void setHp(int);
	void	setY(int);
	void	setX(int);

	int getHp() const;
	int getSize() const;
	int getY() const;
	int getX() const;
	std::string getType() const;

	void	moveLeft();
	void	moveRight();
	void	moveUp();
	void	moveDown();
	bool	collision(int, int);

};

#endif
