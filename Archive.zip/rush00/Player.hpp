/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Player.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:15:50 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:15:57 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PLAYER_H
# define PLAYER_H

#include <iostream>
#include "Ship.hpp"

class Player : public Ship
{
	unsigned int _score;

public:
	Player();
	Player(const char*);
	~Player();
	Player( Player const & src);

	Player & operator=(Player const & rhs);

	unsigned int getScore() const;
	void setScore(unsigned int);

	void	addScore(unsigned int);
	bool	hit(int, int);

};

#endif
