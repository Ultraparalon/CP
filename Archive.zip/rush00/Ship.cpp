/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ship.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:16:24 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:16:26 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Ship.hpp"

Ship::Ship() : _y(10), _x(10)
{
	_size = 1;
	_hp = 10;
	_type = "}";
}

Ship::Ship(int y, int x, int size, int hp, std::string who) : _y(y), _x(x), _size(size), _hp(hp), _type(who) {}

Ship::~Ship() {}

Ship::Ship( Ship const & src)
{
	*this = src;
}

Ship & Ship::operator=(Ship const & rhs)
{
	_hp = rhs.getHp();
	_size = rhs.getSize();
	return (*this);
}

void Ship::shipMoved(int y, int x, const char *who, short color)
{
	wattron(stdscr, COLOR_PAIR(color));
	mvprintw(y, x, who);
	wattroff(stdscr, COLOR_PAIR(color));
}

void Ship::setHp(int hp)	{	_hp = hp;}
void Ship::setX(int val)	{	_x = val;}
void Ship::setY(int val)	{	_y = val;}

int Ship::getHp() const	{	return _hp;	}
int Ship::getSize() const	{	return _size;}
int	Ship::getY() const {	return _y;	}
int	Ship::getX() const	{	return _x;	}
std::string	Ship::getType() const {	return _type; }

void	Ship::moveLeft()
{
	if (_x > 1) _x--;
}
void	Ship::moveRight()
{
	if (_x < 99) _x++;
}
void	Ship::moveUp()
{
	if (_y > 1) _y--;

}
void	Ship::moveDown()
{
	if (_y < 49) _y++;
}

bool	Ship::collision(int y, int x)
{
	if (y == _y && x == _x)
		return (true);
	else
		return (false);
}
