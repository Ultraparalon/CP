/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bullet.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:14:08 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:14:11 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BULLET_H
# define BULLET_H

class Bullet
{
    int _y;
    int _x;
    int _course;

public:
    Bullet();
    Bullet(int, int, int);
    ~Bullet();
    Bullet(Bullet const & src);

    Bullet & operator=(Bullet const & rhs);

    void setY(unsigned int);
    void setX(unsigned int);
    void setCourse(unsigned int);
    unsigned int getY() const;
    unsigned int getX() const;

    void    moveBullet();
};

#endif
