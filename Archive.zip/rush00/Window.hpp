/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Window.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/07 10:16:47 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/07 10:16:49 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WINDOW_CLASS_HPP
# define WINDOW_CLASS_HPP

#include <ncurses.h>
#include <iostream>

unsigned int const mapX = 100;
unsigned int const mapY = 50;

class Window
{

public:
    Window(void);
    ~Window(void);

    Window & operator = (Window const & rhs);

    Window(Window const & cpy);
    void initNcurses(void);
    void drawBorders(void);
    void initColors(void);
    void	clear();
};

#endif
