NYANYANYANYANYA

charnge skin:	'1'-'0' numbers 
quit:			'q'
