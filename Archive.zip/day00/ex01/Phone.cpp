/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Phone.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 09:59:47 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 10:00:05 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Phone.hpp"

static void	formated(std::string str)
{
	std::cout << '|';
	if (str.length() > 10)
		std::cout << str.substr(0, 9) << '.';
	else
		std::cout << std::setw(10) << str;
}

void	Book::init(void)
{
	std::cout << "enter first name: ";
	std::cin >> this->firstname;
	std::cout << "enter last name: ";
	std::cin >> this->lastname;
	std::cout << "enter nickname: ";
	std::cin >> this->nickname;
	std::cout << "enter login: ";
	std::cin >> this->login;
	std::cout << "enter postal address: ";
	std::cin >> this->postal;
	std::cout << "enter email address: ";
	std::cin >> this->email;
	std::cout << "enter phone number: ";
	std::cin >> this->phone_number;
	std::cout << "enter birthday date: ";
	std::cin >> this->birthday;
	std::cout << "enter favorite meal: ";
	std::cin >> this->favorite_meal;
	std::cout << "enter underwear color: ";
	std::cin >> this->underwear;
	std::cout << "enter darkest secret: ";
	std::cin >> this->secret;
}

void	Book::show_card(void)
{
	std::cout << "     first name: " << this->firstname << '\n';
	std::cout << "      last name: " << this->lastname << '\n';
	std::cout << "       nickname: " << this->nickname << '\n';
	std::cout << "          login: " << this->login << '\n';
	std::cout << " postal address: " << this->postal << '\n';
	std::cout << "  email address: " << this->email << '\n';
	std::cout << "   phone number: " << this->phone_number << '\n';
	std::cout << "  birthday date: " << this->birthday << '\n';
	std::cout << "  favorite meal: " << this->favorite_meal << '\n';
	std::cout << "underwear color: " << this->underwear << '\n';
	std::cout << " darkest secret: " << this->secret << '\n';
}

void	Book::show(int index)
{
	std::cout << std::setw(10) << index;
	formated(this->firstname);
	formated(this->lastname);
	formated(this->nickname);
	std::cout << '\n';
}
