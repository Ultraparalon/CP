/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Phone.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 10:00:18 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 10:00:21 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHONE_H
# define PHONE_H

# include <iostream>
# include <iomanip>

class Book {

private:
	std::string firstname;
	std::string lastname;
	std::string nickname;
	std::string login;
	std::string postal;
	std::string email;
	std::string phone_number;
	std::string birthday;
	std::string favorite_meal;
	std::string underwear;
	std::string secret;
	
public:
	void	init(void);
	void	show(int index);
	void	show_card(void);
};

#endif
