/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:11:56 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:11:58 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <string>
#include <cstdlib>
#include "Phone.hpp"

static int 	stringtoi(std::string *str)
{
	const char *tmp = str->c_str();
	return (atoi(tmp));
}

static void	search(Book *card, int index)
{
	std::string	str;
	int 		choice;

	std::cout << "     index|first name| last name|  nickname\n";

	for (int i = 0; i < index; i++)
		card[i].show(i + 1);

	std::cout << "enter index: ";
	std::cin >> str;
	if (std::cin.eof())
		return;
	choice = stringtoi(&str);
	if (choice > 0 && choice <= index)
		card[choice - 1].show_card();
	else
		std::cout << "no such index!\n";
}

int main()
{
	std::string choice;
	Book		card[8];
	int			index = 0;

	while (!std::cin.eof())
	{
		std::cout << "enter command: ";
		std::cin >> choice;
		if (choice == "ADD")
		{
			if (index < 8)
			{
				card[index].init();
				index++;
			}
			else
				std::cout << "phonebook is full!\n";
		}
		else if (choice == "SEARCH")
		{
			if (index)
				search(card, index);
			else
				std::cout << "phonebook is empty\n";
		}
		else if (choice == "EXIT" || std::cin.eof())
			break;
		else
			std::cout << "unknown command\n";

		std::cout << '\n';
	}
	std::cout << "Bye bye...\n";
	return (0);
}
