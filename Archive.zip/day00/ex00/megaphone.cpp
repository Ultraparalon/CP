/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   megaphone.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 13:31:49 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 13:31:51 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

int	main(int argc, char **argv)
{
	char *tmp;

	argv++;
	if (argc == 1)
		std::cout << "* LOUD AND UNBEARABLE FEEDBACK NOISE *";
	else
		for (; *argv; argv++)
		{
			tmp = *argv;
			for (; *tmp; tmp++)
				*tmp = toupper(*tmp);
			std::cout << *argv;
		}
	std::cout << '\n';
	return 0;
}
