/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:55 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include "Bureaucrat.hpp"
#include "AForm.hpp"
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"
#include "Intern.hpp"
#include "OfficeBlock.hpp"

int	main()
{
	srand(time(0));

	Intern * idiotOne = new Intern();
	Bureaucrat * hermes = new Bureaucrat("Hermes Conrad", 37);
	Bureaucrat * bob = new Bureaucrat("Bobby Bobson", 123);
	OfficeBlock ob;

	try
	{
		ob.doBureaucracy("mutant pig termination", "Pigley");
	}
	catch (OfficeBlock::NoInternException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoFormException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;
	}

	ob.setIntern(idiotOne);

	try
	{
		ob.doBureaucracy("mutant pig termination", "Pigley");
	}
	catch (OfficeBlock::NoInternException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoFormException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;
	}

	ob.setSigner(bob);

	try
	{
		ob.doBureaucracy("mutant pig termination", "Pigley");
	}
	catch (OfficeBlock::NoInternException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoFormException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;
	}

	ob.setExecutor(hermes);

	try
	{
		ob.doBureaucracy("mutant pig termination", "Pigley");
	}
	catch (OfficeBlock::NoInternException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoFormException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;
	}

	try
	{
		ob.doBureaucracy("shrubbery creation", "Mars");
	}
	catch (OfficeBlock::NoInternException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::NoFormException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowSignerException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (OfficeBlock::LowExecutorException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;
	}

	return (0);
}
