/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OfficeBlock.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/09 13:45:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/09 13:45:54 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OFFICEBLOCK_H
# define OFFICEBLOCK_H

#include "Bureaucrat.hpp"
#include "Intern.hpp"

class OfficeBlock
{
	Intern *		_intern;
	Bureaucrat *	_signer;
	Bureaucrat *	_executor;

public:
	OfficeBlock();
	OfficeBlock(Intern *, Bureaucrat *, Bureaucrat *);
	~OfficeBlock();

	void	setIntern(Intern *);
	void	setSigner(Bureaucrat *);
	void	setExecutor(Bureaucrat *);

	void	doBureaucracy(std::string const &, std::string const &);

	class NoInternException
	{
	public:
		NoInternException() throw();
		NoInternException(NoInternException const &) throw();
		virtual ~NoInternException() throw();
		virtual const char*	what() const throw();
		NoInternException &	operator=(NoInternException const &) throw();
		
	};

	class NoSignerException
	{
	public:
		NoSignerException() throw();
		NoSignerException(NoSignerException const &) throw();
		virtual ~NoSignerException() throw();
		virtual const char*	what() const throw();
		NoSignerException &	operator=(NoSignerException const &) throw();
		
	};

	class NoExecutorException
	{
	public:
		NoExecutorException() throw();
		NoExecutorException(NoExecutorException const &) throw();
		virtual ~NoExecutorException() throw();
		virtual const char*	what() const throw();
		NoExecutorException &	operator=(NoExecutorException const &) throw();
		
	};

	class NoFormException
	{
	public:
		NoFormException() throw();
		NoFormException(NoFormException const &) throw();
		virtual ~NoFormException() throw();
		virtual const char*	what() const throw();
		NoFormException &	operator=(NoFormException const &) throw();
		
	};

	class LowSignerException
	{
	public:
		LowSignerException() throw();
		LowSignerException(LowSignerException const &) throw();
		virtual ~LowSignerException() throw();
		virtual const char*	what() const throw();
		LowSignerException &	operator=(LowSignerException const &) throw();
		
	};

	class LowExecutorException
	{
	public:
		LowExecutorException() throw();
		LowExecutorException(LowExecutorException const &) throw();
		virtual ~LowExecutorException() throw();
		virtual const char*	what() const throw();
		LowExecutorException &	operator=(LowExecutorException const &) throw();
		
	};
	
};

#endif
