/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   OfficeBlock.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/09 13:45:42 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/09 13:45:45 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "OfficeBlock.hpp"

OfficeBlock::OfficeBlock() : _intern(NULL), _signer(NULL), _executor(NULL) {}

OfficeBlock::OfficeBlock(Intern * intern, Bureaucrat * signer, Bureaucrat * executor) : _intern(intern), _signer(signer), _executor(executor) {}

OfficeBlock::~OfficeBlock() {}

void	OfficeBlock::setIntern(Intern * obj)		{	_intern = obj;		}
void	OfficeBlock::setSigner(Bureaucrat * obj)	{	_signer = obj;		}
void	OfficeBlock::setExecutor(Bureaucrat * obj)	{	_executor = obj;	}

void	OfficeBlock::doBureaucracy(std::string const & name,	std::string const & target)
{
	if (!_intern)
		throw OfficeBlock::NoExecutorException();
	if (!_signer)
		throw OfficeBlock::NoSignerException();
	if (!_executor)
		throw OfficeBlock::NoExecutorException();

	AForm * form = _intern->makeForm(name, target);

	if (!form)
		throw OfficeBlock::NoFormException();
	if (!_signer->signForm(*form))
		throw OfficeBlock::LowSignerException();
	if (!_executor->executeForm(*form))
		throw OfficeBlock::LowExecutorException();

}

// NoInternException---------------------------------------------------

OfficeBlock::NoInternException::NoInternException() throw() {}
OfficeBlock::NoInternException::NoInternException(NoInternException const & obj) throw()
{
	*this = obj;
}
OfficeBlock::NoInternException::~NoInternException() throw() {}
const char *	OfficeBlock::NoInternException::what() const throw()
{
	return "No intern found!";
}
OfficeBlock::NoInternException &	OfficeBlock::NoInternException::operator=(NoInternException const &) throw()
{
	return *this;
}

// NoSignerException---------------------------------------------------

OfficeBlock::NoSignerException::NoSignerException() throw() {}
OfficeBlock::NoSignerException::NoSignerException(NoSignerException const & obj) throw()
{
	*this = obj;
}
OfficeBlock::NoSignerException::~NoSignerException() throw() {}
const char *	OfficeBlock::NoSignerException::what() const throw()
{
	return "No signer found!";
}
OfficeBlock::NoSignerException &	OfficeBlock::NoSignerException::operator=(NoSignerException const &) throw()
{
	return *this;
}

// NoExecutorException---------------------------------------------------

OfficeBlock::NoExecutorException::NoExecutorException() throw() {}
OfficeBlock::NoExecutorException::NoExecutorException(NoExecutorException const & obj) throw()
{
	*this = obj;
}
OfficeBlock::NoExecutorException::~NoExecutorException() throw() {}
const char *	OfficeBlock::NoExecutorException::what() const throw()
{
	return "No executor found!";
}
OfficeBlock::NoExecutorException &	OfficeBlock::NoExecutorException::operator=(NoExecutorException const &) throw()
{
	return *this;
}

// NoFormException---------------------------------------------------

OfficeBlock::NoFormException::NoFormException() throw() {}
OfficeBlock::NoFormException::NoFormException(NoFormException const & obj) throw()
{
	*this = obj;
}
OfficeBlock::NoFormException::~NoFormException() throw() {}
const char *	OfficeBlock::NoFormException::what() const throw()
{
	return "No such form!";
}
OfficeBlock::NoFormException &	OfficeBlock::NoFormException::operator=(NoFormException const &) throw()
{
	return *this;
}

// LowSignerException---------------------------------------------------

OfficeBlock::LowSignerException::LowSignerException() throw() {}
OfficeBlock::LowSignerException::LowSignerException(LowSignerException const & obj) throw()
{
	*this = obj;
}
OfficeBlock::LowSignerException::~LowSignerException() throw() {}
const char *	OfficeBlock::LowSignerException::what() const throw()
{
	return "Signer is too low!";
}
OfficeBlock::LowSignerException &	OfficeBlock::LowSignerException::operator=(LowSignerException const &) throw()
{
	return *this;
}

// LowExecutorException---------------------------------------------------

OfficeBlock::LowExecutorException::LowExecutorException() throw() {}
OfficeBlock::LowExecutorException::LowExecutorException(LowExecutorException const & obj) throw()
{
	*this = obj;
}
OfficeBlock::LowExecutorException::~LowExecutorException() throw() {}
const char *	OfficeBlock::LowExecutorException::what() const throw()
{
	return "Executor is too low!";
}
OfficeBlock::LowExecutorException &	OfficeBlock::LowExecutorException::operator=(LowExecutorException const &) throw()
{
	return *this;
}
