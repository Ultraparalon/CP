/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:28 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:36 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	BUREAUCRAT_H
# define BUREAUCRAT_H

#include <iostream>
#include "AForm.hpp"

class AForm;

class Bureaucrat
{
	std::string const	_name;
	int					_grade;

public:
	Bureaucrat();
	Bureaucrat(std::string const &, int);
	Bureaucrat(Bureaucrat const &);
	~Bureaucrat();

	std::string	getName() const;
	int			getGrade() const;

	void	increment();
	void	decrement();
	bool	signForm(AForm &);
	bool	executeForm(AForm const &);

	Bureaucrat &	operator=(Bureaucrat const &);
	Bureaucrat &	operator++();
	Bureaucrat		operator++(int);
	Bureaucrat &	operator--();
	Bureaucrat		operator--(int);

	class GradeTooHighException
	{
	public:
		GradeTooHighException() throw();
		GradeTooHighException(GradeTooHighException const &) throw();
		virtual ~GradeTooHighException() throw();
		virtual const char*	what() const throw();
		GradeTooHighException &	operator=(GradeTooHighException const &) throw();
		
	};

	class GradeTooLowException
	{
	public:
		GradeTooLowException() throw();
		GradeTooLowException(GradeTooLowException const &) throw();
		virtual ~GradeTooLowException() throw();
		virtual const char*	what() const throw();
		GradeTooLowException &	operator=(GradeTooLowException const &) throw();
		
	};
};

std::ostream &	operator<<(std::ostream &, Bureaucrat const &);

#endif
