/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 16:40:29 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 16:40:33 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	FORM_H
# define FORM_H

#include <iostream>
#include "Bureaucrat.hpp"

class Bureaucrat;

class Form
{
	std::string const	_name;
	int	const			_sign_grade;
	int const			_exec_grade;
	bool				_signed;

public:
	Form();
	Form(std::string const &, int, int);
	Form(Form const &);
	~Form();

	std::string	getName() const;
	int			getSignGrade() const;
	int			getExecGrade() const;
	bool		getSigned() const;

	void	beSigned(Bureaucrat const &);

	Form &	operator=(Form const &);

	class GradeTooHighException
	{
	public:
		GradeTooHighException() throw();
		GradeTooHighException(GradeTooHighException const &) throw();
		virtual ~GradeTooHighException() throw();
		virtual const char*	what() const throw();
		GradeTooHighException &	operator=(GradeTooHighException const &) throw();
		
	};

	class GradeTooLowException
	{
	public:
		GradeTooLowException() throw();
		GradeTooLowException(GradeTooLowException const &) throw();
		virtual ~GradeTooLowException() throw();
		virtual const char*	what() const throw();
		GradeTooLowException &	operator=(GradeTooLowException const &) throw();
		
	};
};

std::ostream &	operator<<(std::ostream &, Form const &);

#endif
