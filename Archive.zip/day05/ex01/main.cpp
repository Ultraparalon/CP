/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:55 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Bureaucrat.hpp"
#include "Form.hpp"

int	main()
{
	Bureaucrat	lol("lol", 140);
	Bureaucrat	kek("kek", 10);

	Form	form150("form150", 150, 150);
	Form	form100("form100", 100, 100);

	try
	{
		Form	form151("form151", 151, 151);
	}
	catch (Form::GradeTooHighException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (Form::GradeTooLowException & e)
	{
		std::cout << e.what() << std::endl;			
	}

	lol.signForm(form100);

	lol.signForm(form150);
	lol.signForm(form150);

	return (0);
}
