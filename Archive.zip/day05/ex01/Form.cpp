/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 16:40:21 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 16:40:22 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Form.hpp"

Form::Form() : _name("default"), _sign_grade(1), _exec_grade(1), _signed(0) {}

Form::Form(std::string const & name, int sign, int exec) : _name(name), _sign_grade(sign), _exec_grade(exec), _signed(0)
{
	if (sign < 1 || exec < 1)
		throw Form::GradeTooHighException();
	else if (sign > 150 || exec > 150)
		throw Form::GradeTooLowException();
}

Form::Form(Form const & obj) : _name(obj.getName()), _sign_grade(obj.getSignGrade()), _exec_grade(obj.getExecGrade())
{	*this = obj;	}

Form::~Form() {}

std::string	Form::getName() const		{	return _name;		}
int			Form::getSignGrade() const	{	return _sign_grade;	}
int			Form::getExecGrade() const	{	return _exec_grade;	}
bool		Form::getSigned()	const	{	return _signed;		}

void	Form::beSigned(Bureaucrat const & obj)
{
	if (obj.getGrade() > _sign_grade)
		throw Form::GradeTooLowException();
	_signed = true;
}

Form &	Form::operator=(Form const & obj)
{
	_signed = obj.getSigned();
	return *this;
}

// GradeTooHighException---------------------------------------------------

Form::GradeTooHighException::GradeTooHighException() throw() {}
Form::GradeTooHighException::GradeTooHighException(GradeTooHighException const & obj) throw()
{
	*this = obj;
}
Form::GradeTooHighException::~GradeTooHighException() throw() {}
const char *	Form::GradeTooHighException::what() const throw()
{
	return "Grade is too high!";
}
Form::GradeTooHighException &	Form::GradeTooHighException::operator=(GradeTooHighException const &) throw()
{
	return *this;
}

// GradeTooLowException----------------------------------------------------

Form::GradeTooLowException::GradeTooLowException() throw() {}
Form::GradeTooLowException::GradeTooLowException(GradeTooLowException const & obj) throw()
{
	*this = obj;
}
Form::GradeTooLowException::~GradeTooLowException() throw() {}
const char *	Form::GradeTooLowException::what() const throw()
{
	return "Grade is too low!";
}
Form::GradeTooLowException &	Form::GradeTooLowException::operator=(GradeTooLowException const &) throw()
{
	return *this;
}

