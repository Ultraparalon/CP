/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:45 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:46 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

Bureaucrat::Bureaucrat() : _name("default"), _grade(150) {}

Bureaucrat::Bureaucrat(std::string const & name, int grade) : _name(name)
{
	if (grade < 1)
		throw Bureaucrat::GradeTooHighException();
	else if (grade > 150)
		throw Bureaucrat::GradeTooLowException();
	else
		_grade = grade;
}

Bureaucrat::Bureaucrat(Bureaucrat const & obj)	{	*this = obj;	}

Bureaucrat::~Bureaucrat() {}

std::string	Bureaucrat::getName() const	{	return _name;	}
int			Bureaucrat::getGrade() const{	return _grade;	}

void	Bureaucrat::increment()
{
	if (_grade == 1)
		throw Bureaucrat::GradeTooHighException();
	else
		_grade--;
}

void	Bureaucrat::decrement()
{
	if (_grade == 150)
		throw Bureaucrat::GradeTooLowException();
	else
		_grade++;
}

Bureaucrat &	Bureaucrat::operator=(Bureaucrat const & obj)
{
	_grade = obj.getGrade();
	return *this;
}

Bureaucrat &	Bureaucrat::operator++()
{
	if (_grade == 1)
		throw Bureaucrat::GradeTooHighException();
	else
		_grade--;
	return *this;
}

Bureaucrat		Bureaucrat::operator++(int)
{
	Bureaucrat	ret(*this);

	if (_grade == 1)
		throw Bureaucrat::GradeTooHighException();
	else
		_grade--;
	return ret;
}

Bureaucrat &	Bureaucrat::operator--()
{
	if (_grade == 150)
		throw Bureaucrat::GradeTooLowException();
	else
		_grade++;
	return *this;
}

Bureaucrat		Bureaucrat::operator--(int)
{
	Bureaucrat	ret(*this);

	if (_grade == 150)
		throw Bureaucrat::GradeTooLowException();
	else
		_grade++;
	return ret;
}

std::ostream &	operator<<(std::ostream & str, Bureaucrat const & obj)
{
	str << obj.getName() << ", bureaucrat grade " << obj.getGrade() << ".\n";
	return str;
}

// GradeTooHighException---------------------------------------------------

Bureaucrat::GradeTooHighException::GradeTooHighException() throw() {}
Bureaucrat::GradeTooHighException::GradeTooHighException(GradeTooHighException const & obj) throw()
{
	*this = obj;
}
Bureaucrat::GradeTooHighException::~GradeTooHighException() throw() {}
const char *	Bureaucrat::GradeTooHighException::what() const throw()
{
	return "Grade is too high!";
}
Bureaucrat::GradeTooHighException &	Bureaucrat::GradeTooHighException::operator=(GradeTooHighException const &) throw()
{
	return *this;
}

// GradeTooLowException----------------------------------------------------

Bureaucrat::GradeTooLowException::GradeTooLowException() throw() {}
Bureaucrat::GradeTooLowException::GradeTooLowException(GradeTooLowException const & obj) throw()
{
	*this = obj;
}
Bureaucrat::GradeTooLowException::~GradeTooLowException() throw() {}
const char *	Bureaucrat::GradeTooLowException::what() const throw()
{
	return "Grade is too low!";
}
Bureaucrat::GradeTooLowException &	Bureaucrat::GradeTooLowException::operator=(GradeTooLowException const &) throw()
{
	return *this;
}
