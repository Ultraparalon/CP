/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:55 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Bureaucrat.hpp"

int	main()
{
	Bureaucrat	lol("lol", 140);
	Bureaucrat	kek("kek", 10);
	std::cout << "---------------------------------------------------\n";
	try
	{
		Bureaucrat	test("test", 151);
	}
	catch (Bureaucrat::GradeTooHighException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (Bureaucrat::GradeTooLowException & e)
	{
		std::cout << e.what() << std::endl;			
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;			
	}
	std::cout << "---------------------------------------------------\n";
	try
	{
		Bureaucrat	test("test", 0);
	}
	catch (Bureaucrat::GradeTooHighException & e)
	{
		std::cout << e.what() << std::endl;
	}
	catch (Bureaucrat::GradeTooLowException & e)
	{
		std::cout << e.what() << std::endl;			
	}
	catch (std::exception & e)
	{
		std::cout << e.what() << std::endl;			
	}
	std::cout << "---------------------------------------------------\n";
	for (int i = 0; i < 15; i++)
	{
		try
		{
			lol--;
		}
		catch (Bureaucrat::GradeTooHighException & e)
		{
			std::cout << e.what() << std::endl;
		}
		catch (Bureaucrat::GradeTooLowException & e)
		{
			std::cout << e.what() << std::endl;			
		}
		catch (std::exception & e)
		{
			std::cout << e.what() << std::endl;			
		}
		std::cout << lol;
	}
	std::cout << "---------------------------------------------------\n";
	for (int i = 0; i < 15; i++)
	{
		try
		{
			kek++;
		}
		catch (Bureaucrat::GradeTooHighException & e)
		{
			std::cout << e.what() << std::endl;
		}
		catch (Bureaucrat::GradeTooLowException & e)
		{
			std::cout << e.what() << std::endl;			
		}
		catch (std::exception & e)
		{
			std::cout << e.what() << std::endl;			
		}
		std::cout << kek;
	}
	std::cout << "---------------------------------------------------\n";
	Bureaucrat	testin("testin", 10);
	Bureaucrat	testde("testde", 140);

	for (int i = 0; i < 15; i++)
	{
		try
		{
			testde.decrement();
		}
		catch (Bureaucrat::GradeTooHighException & e)
		{
			std::cout << e.what() << std::endl;
		}
		catch (Bureaucrat::GradeTooLowException & e)
		{
			std::cout << e.what() << std::endl;			
		}
		catch (std::exception & e)
		{
			std::cout << e.what() << std::endl;			
		}
		std::cout << testde;
	}
	std::cout << "---------------------------------------------------\n";
	for (int i = 0; i < 15; i++)
	{
		try
		{
			testin.increment();
		}
		catch (Bureaucrat::GradeTooHighException & e)
		{
			std::cout << e.what() << std::endl;
		}
		catch (Bureaucrat::GradeTooLowException & e)
		{
			std::cout << e.what() << std::endl;			
		}
		catch (std::exception & e)
		{
			std::cout << e.what() << std::endl;			
		}
		std::cout << testin;
	}
	return (0);
}
