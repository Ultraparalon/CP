/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.cpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 20:59:33 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 20:59:36 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ShrubberyCreationForm.hpp"

ShrubberyCreationForm::ShrubberyCreationForm() {}

ShrubberyCreationForm::ShrubberyCreationForm(std::string const & target) : AForm(target, 145, 137) {}

ShrubberyCreationForm::ShrubberyCreationForm(ShrubberyCreationForm const & obj) : AForm(obj.getName(), 145, 137) {	*this = obj;	}

ShrubberyCreationForm::~ShrubberyCreationForm() {}

void	ShrubberyCreationForm::execute(Bureaucrat const & obj) const
{
	if (obj.getGrade() > this->getExecGrade())
		throw ShrubberyCreationForm::GradeTooLowException();
	std::ofstream	ofs(getName() + "_shrubbery", std::ios_base::app);
	ofs << "  A  \n";
	ofs << " /A\\ \n";
	ofs << "/*A*\\\n";
	ofs << "  |  \n";
	ofs << "=====\n";
	ofs.close();
}

ShrubberyCreationForm & ShrubberyCreationForm::operator=(ShrubberyCreationForm const & obj)
{
	AForm::operator=(obj);
	return *this;
}
