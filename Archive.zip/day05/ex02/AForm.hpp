/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AForm.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 16:40:29 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 16:40:33 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef	AFORM_H
# define AFORM_H

#include <iostream>
#include "Bureaucrat.hpp"

class Bureaucrat;

class AForm
{
	std::string const	_name;
	int	const			_sign_grade;
	int const			_exec_grade;
	bool				_signed;

public:
	AForm();
	AForm(std::string const &, int, int);
	AForm(AForm const &);
	virtual ~AForm();

	std::string	getName() const;
	int			getSignGrade() const;
	int			getExecGrade() const;
	bool		getSigned() const;

	void			beSigned(Bureaucrat const &);
	virtual void	execute(Bureaucrat const &) const = 0;

	AForm &	operator=(AForm const &);

	class GradeTooHighException
	{
	public:
		GradeTooHighException() throw();
		GradeTooHighException(GradeTooHighException const &) throw();
		virtual ~GradeTooHighException() throw();
		virtual const char*	what() const throw();
		GradeTooHighException &	operator=(GradeTooHighException const &) throw();
		
	};

	class GradeTooLowException
	{
	public:
		GradeTooLowException() throw();
		GradeTooLowException(GradeTooLowException const &) throw();
		virtual ~GradeTooLowException() throw();
		virtual const char*	what() const throw();
		GradeTooLowException &	operator=(GradeTooLowException const &) throw();
		
	};
};

std::ostream &	operator<<(std::ostream &, AForm const &);

#endif
