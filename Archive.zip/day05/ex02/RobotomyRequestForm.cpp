/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RobotomyRequestForm.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 21:00:02 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 21:00:03 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "RobotomyRequestForm.hpp"

RobotomyRequestForm::RobotomyRequestForm() {}

RobotomyRequestForm::RobotomyRequestForm(std::string const & target) : AForm(target, 72, 45) {}

RobotomyRequestForm::RobotomyRequestForm(RobotomyRequestForm const & obj) : AForm(obj.getName(), 72, 45) {	*this = obj;	}

RobotomyRequestForm::~RobotomyRequestForm() {}

void	RobotomyRequestForm::execute(Bureaucrat const & obj) const
{
	if (obj.getGrade() > this->getExecGrade())
		throw RobotomyRequestForm::GradeTooLowException();
	std::cout << "* drilling noises *\n";
	if (rand() % 2)
		std::cout << getName() << " been successfully robotomized.\n";
	else
		std::cout << getName() << " failed to be robotomized.\n";
}

RobotomyRequestForm & RobotomyRequestForm::operator=(RobotomyRequestForm const & obj)
{
	AForm::operator=(obj);
	return *this;
}
