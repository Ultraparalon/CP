/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PresidentialPardonForm.cpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 21:00:31 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 21:00:32 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PresidentialPardonForm.hpp"

PresidentialPardonForm::PresidentialPardonForm() {}

PresidentialPardonForm::PresidentialPardonForm(std::string const & target) : AForm(target, 25, 5) {}

PresidentialPardonForm::PresidentialPardonForm(PresidentialPardonForm const & obj) : AForm(obj.getName(), 25, 5) {	*this = obj;	}

PresidentialPardonForm::~PresidentialPardonForm() {}

void	PresidentialPardonForm::execute(Bureaucrat const & obj) const
{
	if (obj.getGrade() > this->getExecGrade())
		throw PresidentialPardonForm::GradeTooLowException();
	std::cout << getName() << " has been pardoned by Zaphod Beeblebrox.\n";
}

PresidentialPardonForm & PresidentialPardonForm::operator=(PresidentialPardonForm const & obj)
{
	AForm::operator=(obj);
	return *this;
}
