/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.hpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 20:59:39 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 20:59:41 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SHRUBBERYCREATIONFORM_H
# define SHRUBBERYCREATIONFORM_H

#include <fstream>
#include "AForm.hpp"

class ShrubberyCreationForm : public AForm
{

public:
	ShrubberyCreationForm();
	ShrubberyCreationForm(std::string const & name);
	ShrubberyCreationForm(ShrubberyCreationForm const &);
	~ShrubberyCreationForm();

	void	execute(Bureaucrat const &) const;
	
	ShrubberyCreationForm & operator=(ShrubberyCreationForm const &);
};

#endif 
