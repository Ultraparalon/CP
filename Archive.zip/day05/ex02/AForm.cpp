/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AForm.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 16:40:21 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 16:40:22 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "AForm.hpp"

AForm::AForm() : _name("default"), _sign_grade(1), _exec_grade(1), _signed(0) {}

AForm::AForm(std::string const & name, int sign, int exec) : _name(name), _sign_grade(sign), _exec_grade(exec), _signed(0)
{
	if (sign < 1 || exec < 1)
		throw AForm::GradeTooHighException();
	else if (sign > 150 || exec > 150)
		throw AForm::GradeTooLowException();
}

AForm::AForm(AForm const & obj) : _name(obj.getName()), _sign_grade(obj.getSignGrade()), _exec_grade(obj.getExecGrade())
{	*this = obj;	}

AForm::~AForm() {}

std::string	AForm::getName() const		{	return _name;		}
int			AForm::getSignGrade() const	{	return _sign_grade;	}
int			AForm::getExecGrade() const	{	return _exec_grade;	}
bool		AForm::getSigned()	const	{	return _signed;		}

void	AForm::beSigned(Bureaucrat const & obj)
{
	if (obj.getGrade() > _sign_grade)
		throw AForm::GradeTooLowException();
	_signed = true;
}

AForm &	AForm::operator=(AForm const & obj)
{
	_signed = obj.getSigned();
	return *this;
}

// GradeTooHighException---------------------------------------------------

AForm::GradeTooHighException::GradeTooHighException() throw() {}
AForm::GradeTooHighException::GradeTooHighException(GradeTooHighException const & obj) throw()
{
	*this = obj;
}
AForm::GradeTooHighException::~GradeTooHighException() throw() {}
const char *	AForm::GradeTooHighException::what() const throw()
{
	return "Grade is too high!";
}
AForm::GradeTooHighException &	AForm::GradeTooHighException::operator=(GradeTooHighException const &) throw()
{
	return *this;
}

// GradeTooLowException----------------------------------------------------

AForm::GradeTooLowException::GradeTooLowException() throw() {}
AForm::GradeTooLowException::GradeTooLowException(GradeTooLowException const & obj) throw()
{
	*this = obj;
}
AForm::GradeTooLowException::~GradeTooLowException() throw() {}
const char *	AForm::GradeTooLowException::what() const throw()
{
	return "Grade is too low!";
}
AForm::GradeTooLowException &	AForm::GradeTooLowException::operator=(GradeTooLowException const &) throw()
{
	return *this;
}

