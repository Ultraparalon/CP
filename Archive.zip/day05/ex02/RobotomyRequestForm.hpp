/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RobotomyRequestForm.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 21:00:08 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 21:00:10 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ROBOTOMYREQUESTFORM_H
# define ROBOTOMYREQUESTFORM_H

#include <cstdlib>
#include "AForm.hpp"

class RobotomyRequestForm : public AForm
{

public:
	RobotomyRequestForm();
	RobotomyRequestForm(std::string const & name);
	RobotomyRequestForm(RobotomyRequestForm const &);
	~RobotomyRequestForm();

	void	execute(Bureaucrat const &) const;
	
	RobotomyRequestForm & operator=(RobotomyRequestForm const &);
};

#endif 
