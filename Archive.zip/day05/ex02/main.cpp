/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:55 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include "Bureaucrat.hpp"
#include "AForm.hpp"
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"

int	main()
{
	srand(time(0));

	Bureaucrat	lol("lol", 150);
	Bureaucrat	kek("kek", 1);
	Bureaucrat	test("test", 5);

	AForm *	pardon = new PresidentialPardonForm("Corretor");
	AForm *	request = new RobotomyRequestForm("Corretor");
	AForm *	creation = new ShrubberyCreationForm("Earth");

	lol.signForm(*pardon);
	lol.signForm(*request);
	lol.signForm(*creation);

	kek.signForm(*pardon);
	kek.signForm(*request);
	kek.signForm(*creation);

	lol.executeForm(*pardon);
	lol.executeForm(*request);
	lol.executeForm(*creation);

	kek.executeForm(*pardon);
	kek.executeForm(*request);
	kek.executeForm(*creation);

	test.executeForm(*pardon);

	delete pardon;
	delete request;
	delete creation;

	return (0);
}
