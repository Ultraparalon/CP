/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PresidentialPardonForm.hpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 21:00:36 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 21:00:37 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PRESIDENTALPARDONFORM_H
# define PRESIDENTALPARDONFORM_H

#include "AForm.hpp"

class PresidentialPardonForm : public AForm
{

public:
	PresidentialPardonForm();
	PresidentialPardonForm(std::string const & name);
	PresidentialPardonForm(PresidentialPardonForm const &);
	~PresidentialPardonForm();

	void	execute(Bureaucrat const &) const;
	
	PresidentialPardonForm & operator=(PresidentialPardonForm const &);
};

#endif 
