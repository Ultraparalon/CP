/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/08 12:11:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/08 12:11:55 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ctime>
#include "Bureaucrat.hpp"
#include "AForm.hpp"
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"
#include "Intern.hpp"

int	main()
{
	srand(time(0));

	Intern	intern;

	AForm * pardon;
	AForm * request;
	AForm * creation;
	AForm * test;

	pardon = intern.makeForm("presidential pardon", "Corrector");
	request = intern.makeForm("robotomy request", "Corrector");
	creation = intern.makeForm("shrubbery creation", "Earth");
	test = intern.makeForm("dasdwadaw", "test");

	delete pardon;
	delete request;
	delete creation;

	return (0);
}
