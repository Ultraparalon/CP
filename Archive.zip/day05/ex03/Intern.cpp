/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Intern.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/09 11:19:00 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/09 11:19:03 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Intern.hpp"

Intern::Intern() {}
Intern::Intern(Intern const & obj)	{	*this = obj;	}
Intern::~Intern() {}

AForm *	Intern::makeForm(std::string const & form, std::string const & target)
{
	AForm * ret;

	if (form == "robotomy request")
		ret = new RobotomyRequestForm(target);
	else if (form == "presidential pardon")
		ret = new PresidentialPardonForm(target);
	else if (form == "shrubbery creation")
		ret = new ShrubberyCreationForm(target);
	else
		ret = NULL;

	if (ret)
		std::cout << "Intern creates " << form << std::endl;
	else
		std::cout << "Intern failed to create " << form << std::endl;

	return (ret);
}

Intern &	Intern::operator=(Intern const &)
{
	return *this;
}
