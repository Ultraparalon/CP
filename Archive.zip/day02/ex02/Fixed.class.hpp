/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:24:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:24:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_CLASS_HPP
# define FIXED_CLASS_HPP

#include <iostream>
#include <cmath>

class Fixed {

	int					_val;
	static int const	_bits;

public:
	Fixed();
	Fixed(int const & val);
	Fixed(float const & val);
	Fixed(Fixed const & copy);
	~Fixed();

	int		getRawBits() const;
	void	setRawBits(int const raw);
	int		toInt() const;
	float	toFloat() const;

	static Fixed &	min(Fixed & fix1, Fixed & fix2);
	static Fixed &	max(Fixed & fix1, Fixed & fix2);
	static Fixed const &	min(Fixed const & fix1, Fixed const & fix2);
	static Fixed const &	max(Fixed const & fix1, Fixed const & fix2);

	Fixed & operator=(Fixed const & fixed);

	bool	operator>(Fixed const & fixed)	const;
	bool	operator<(Fixed const & fixed)	const;
	bool	operator>=(Fixed const & fixed) const;
	bool	operator<=(Fixed const & fixed) const;
	bool	operator==(Fixed const & fixed) const;
	bool	operator!=(Fixed const & fixed) const;

	Fixed 	operator+(Fixed const &	fixed)	const;
	Fixed 	operator-(Fixed const & fixed)	const;
	Fixed 	operator*(Fixed const & fixed)	const;
	Fixed 	operator/(Fixed const & fixed)	const;

	Fixed &	operator++();
	Fixed 	operator++(int post);
	Fixed &	operator--();
	Fixed 	operator--(int post);
	
};

std::ostream & operator<<(std::ostream & o, Fixed const & r);

#endif
