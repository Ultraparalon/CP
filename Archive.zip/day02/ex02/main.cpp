/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:25:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:25:24 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include "Fixed.class.hpp"

int	main()
{
	Fixed 		a;
	Fixed		d(42);
	Fixed		c(42.03f);
	float		x = 42.03f;
	float		z = 42;

	if (d > c)
		std::cout << "d is bigger\n";
	else
		std::cout << "c is bigger\n";

	if (d == c)
		std::cout << "d and c are equal\n";
	else
		std::cout << "d and c not equal\n";

	std::cout << "Fixed: " << d + c << '\n';
	std::cout << "Fixed: " << d / a << '\n';
	std::cout << "Fixed: " << a / a << '\n';
	std::cout << "float: " << 1.01f / 0.00f << '\n';
	std::cout << "float: " << 0.00f / 0.00f << '\n';
	std::cout << "Fixed: " << d++ << '\n';
	std::cout << "float: " << z++ << '\n';
	std::cout << "Fixed: " << c++ << '\n';
	std::cout << "float: " << x++ << '\n';
	std::cout << "Fixed: " << d << '\n';
	std::cout << "float: " << z << '\n';
	std::cout << "Fixed: " << c << '\n';
	std::cout << "float: " << x << '\n';

	Fixed const	b(Fixed(5.05f) * Fixed(2));

	std::cout << a << std::endl;
	std::cout << ++a << std::endl;
	std::cout << a << std::endl;
	std::cout << a++ << std::endl;
	std::cout << a << std::endl;

	std::cout << b << std::endl;

	std::cout << Fixed::max(a, b) << std::endl;

	return (0);
}
