/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:25:05 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:25:07 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.class.hpp"

Fixed::Fixed() : _val(0) {}

Fixed::Fixed(int const & val)
{
	setRawBits(val << this->_bits);
}

Fixed::Fixed(float const & val)
{
	setRawBits(roundf(val * (1 << this->_bits)));
}

Fixed::Fixed(Fixed const & copy)
{
	*this = copy;
}

Fixed::~Fixed() {}

int	Fixed::getRawBits() const
{
	return _val;
}

void	Fixed::setRawBits(int const raw)
{
	_val = raw;
}

int 	Fixed::toInt() const
{
	return (_val >> _bits);
}

float 	Fixed::toFloat() const
{
	return ((float)_val / (1 << _bits));
}

Fixed &	Fixed::min(Fixed & fix1, Fixed & fix2)
{
	return (fix1.toFloat() < fix2.toFloat()) ? fix1 : fix2;
}

Fixed &	Fixed::max(Fixed & fix1, Fixed & fix2)
{
	return (fix1.toFloat() > fix2.toFloat()) ? fix1 : fix2;
}

Fixed const &	Fixed::min(Fixed const & fix1, Fixed const & fix2)
{
	return (fix1.toFloat() < fix2.toFloat()) ? fix1 : fix2;
}

Fixed const &	Fixed::max(Fixed const & fix1, Fixed const & fix2)
{
	return (fix1.toFloat() > fix2.toFloat()) ? fix1 : fix2;
}

Fixed &	Fixed::operator=(Fixed const & fixed)
{
	this->_val = fixed.getRawBits();
	return *this;
}

bool	Fixed::operator>(Fixed const & fixed) const
{	return (_val > fixed.getRawBits());		}

bool	Fixed::operator<(Fixed const & fixed) const
{	return (_val < fixed.getRawBits()); 	}

bool	Fixed::operator>=(Fixed const & fixed) const
{	return (_val >= fixed.getRawBits());	}

bool	Fixed::operator<=(Fixed const & fixed) const
{	return (_val <= fixed.getRawBits());	}

bool	Fixed::operator==(Fixed const & fixed) const
{	return (_val == fixed.getRawBits());	}

bool	Fixed::operator!=(Fixed const & fixed) const
{	return (_val != fixed.getRawBits());	}

Fixed 	Fixed::operator+(Fixed const & fixed) const
{	return (Fixed(this->toFloat() + fixed.toFloat()));	}

Fixed 	Fixed::operator-(Fixed const & fixed) const
{	return (Fixed(this->toFloat() - fixed.toFloat()));	}

Fixed 	Fixed::operator*(Fixed const & fixed) const
{	return (Fixed(this->toFloat() * fixed.toFloat()));	}

Fixed 	Fixed::operator/(Fixed const & fixed) const
{
	if (!fixed.toFloat())
	{
		std::cout << "Dividing by zero! Value set to ";
		return (Fixed(0));
	}
	else
		return (Fixed(this->toFloat() / fixed.toFloat()));
}

Fixed &	Fixed::operator++()
{
	this->_val = this->_val + (1 << this->_bits);
	return (*this);
}

Fixed 	Fixed::operator++(int post)
{
	(void)post;
	Fixed ret(*this);

	this->_val = this->_val + (1 << this->_bits);
	return (ret);
}

Fixed &	Fixed::operator--()
{
	this->_val = this->_val - (1 << this->_bits);
	return (*this);
}

Fixed 	Fixed::operator--(int post)
{
	(void)post;
	Fixed ret(*this);

	this->_val = this->_val - (1 << this->_bits);
	return (ret);
}

std::ostream & operator<<(std::ostream & stream, Fixed const & fixed)
{
	stream << fixed.toFloat();
	return (stream);
}

int const Fixed::_bits = 8;
