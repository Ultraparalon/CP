/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:25:05 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:25:07 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.class.hpp"

Fixed::Fixed() : _val(0)
{
	std::cout << "Default constructor called\n";
}

Fixed::Fixed(int const & val)
{
	std::cout << "Int constructor called\n";
	this->_val = (val << this->_bits);
}

Fixed::Fixed(float const & val)
{
	std::cout << "Float constructor called\n";
	this->_val = roundf(val * (1 << this->_bits));
}

Fixed::Fixed(Fixed const & copy)
{
	std::cout << "Copy constructor called\n";
	*this = copy;
}

Fixed::~Fixed()
{
	std::cout << "Destructor called\n";
}

int	Fixed::getRawBits() const
{
	return _val;
}

void	Fixed::setRawBits(int const raw)
{
	_val = raw;
}

int 	Fixed::toInt() const
{
	return (_val >> _bits);
}

float 	Fixed::toFloat() const
{
	return ((float)_val / (1 << _bits));
}

Fixed &	Fixed::operator=(Fixed const & ass)
{
	std::cout << "Assignation operator called\n";
	this->_val = ass.getRawBits();

	return *this;
}

std::ostream & operator<<(std::ostream & stream, Fixed const & tmp)
{
	stream << tmp.toFloat();
	return (stream);
}

int const Fixed::_bits = 8;
