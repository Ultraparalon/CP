/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:24:53 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:24:56 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_CLASS_HPP
# define FIXED_CLASS_HPP

#include <iostream>
#include <cmath>

class Fixed {

	int					_val;
	static int const	_bits;

public:
	Fixed();
	Fixed(int const & val);
	Fixed(float const & val);
	Fixed(Fixed const & copy);
	~Fixed();

	int		getRawBits() const;
	void	setRawBits(int const raw);
	int		toInt() const;
	float	toFloat() const;

	Fixed & operator=(Fixed const & ass);
	
};

std::ostream & operator<<(std::ostream & o, Fixed const & r);

#endif
