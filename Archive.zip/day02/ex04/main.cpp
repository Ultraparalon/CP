/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:25:19 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:25:24 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <sstream>
#include "Fixed.class.hpp"

std::string eval(std::string str, std::string eva)
{
	std::size_t pos = str.find(eva);

	Fixed	a(std::stof(str));
	Fixed	b(std::stof(str.substr(pos + 1)));

	std::stringstream	ret;

	if (eva == "+")
		ret << a + b;
	if (eva == "-")
		ret << a - b;
	if (eva == "*")
		ret << a * b;
	if (eva == "/")
		ret << a / b;

	return (ret.str());
}

bool	cut(std::string str)
{
	std::size_t ret = str.find(" ");
	if (ret != std::string::npos)
	{
		return (true);
	}
	return (false);
}

std::size_t findStart(std::string str)
{
	std::size_t start = 0;
	if (start != std::string::npos)
	{		
		while(cut(str.substr(start)))
			start++;
	}
	return start;
}

std::size_t findEnd(std::string str)
{
	std::size_t end = str.find(" ");
	if (end != std::string::npos)
	{
		return (end);
	}
	return str.length();
}

bool	multiply(std::string & str, std::string action)
{
	std::cout << "action: " << action << ", str: " << str << '\n';
	std::size_t pos = str.find(action);
	std::size_t bracket = str.find(")");
	if (bracket != std::string::npos && bracket < pos)
		return (false);
	if (pos != std::string::npos)
	{
		if (action == "- ")
			action = "-";
		std::size_t start = findStart(str.substr(0 , pos - 1));
		std::size_t end = findEnd(str.substr(pos + 2));



		str.replace(start, pos + 2 + end, eval(str.substr(start), action));
		return (true);
	}
	return (false);
}

void	cutbr(std::string & str)
{
	std::size_t pos = str.find(")");
	if (pos != std::string::npos)
	{
		str.replace(0, pos + 1, str.substr(0, pos - 1));
	}
}

std::string	wizard(std::string str)
{
	std::size_t pos = str.find("(");
	std::string buff;

	std::cout << str << '\n';

	if (pos != std::string::npos)
	{
		std::string buff;
		buff = wizard(str.substr(pos + 2));
		// std::cout << "string before: " << str << '\n';
		str.resize(pos);
		// std::cout << "string  after: " << str << '\n';
		str += buff;
		// std::size_t end = str.find(")");
		// str.replace(pos, end, buff);

		// std::cout << "cutted: " << str << '\n';

	}
		while (multiply(str, "*"));
		while (multiply(str, "/"));
		while (multiply(str, "+"));
		while (multiply(str, "- "));
		cutbr(str);




		// std::cout << "after: " << str << '\n';

	return (str);
}

int	main(int argc, char **argv)
{
	if (argc == 2)
	{
		std::cout << wizard(argv[1]) << '\n';
	}
	else
		std::cout << "Usage: eval_expr [math expression]\n";

	return (0);
}
