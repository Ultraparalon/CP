/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.class.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vkaidans <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/02 16:25:05 by vkaidans          #+#    #+#             */
/*   Updated: 2018/10/02 16:25:07 by vkaidans         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.class.hpp"

Fixed::Fixed() : _val(0)
{
	std::cout << "Default constructor called\n";
}

Fixed::Fixed(Fixed const & copy)
{
	std::cout << "Copy constructor called\n";
	*this = copy;
}

Fixed::~Fixed()
{
	std::cout << "Destructor called\n";
}

Fixed &	Fixed::operator=(Fixed const & ass)
{
	std::cout << "Assignation operator called\n";
	this->_val = ass.getRawBits();

	return *this;
}

int	Fixed::getRawBits() const
{
	std::cout << "getRawBits member function called\n";
	return _val;
}

void	Fixed::setRawBits(int const raw)
{
	_val = raw;
}

int const Fixed::_bits = 8;
